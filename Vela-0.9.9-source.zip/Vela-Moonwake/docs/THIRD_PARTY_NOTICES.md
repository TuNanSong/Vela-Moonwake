# 第三方来源与许可

Vela 由多个独立项目组合而成。请阅读每个上游项目及随附许可证，尤其是在修改、提供网络服务或重新分发应用包时。

| 项目 | 在 Vela 中的用途 | 上游许可 / 依据 |
| --- | --- | --- |
| [DiPlay](https://github.com/carlito12345/DiPlay) | Vela 源码拆分前所在的相关项目；本仓库不包含 DiPlay Android 应用模块。 | GPL-3.0；原工作区使用的许可证副本见 [`../licenses/DiPlay-LICENSE.txt`](../licenses/DiPlay-LICENSE.txt)。 |
| [MacPlay](https://github.com/Roylyl/MacPlay) | iPhone CarPlay 接收、蓝牙桥接、音视频运行时与相关补丁的来源。 | GPL-3.0-or-later；补丁基于提交 `ccac70f03d3620493941c23484d63ef8951b5e38`。许可与 NOTICE 见 `licenses/`。 |
| [Go Music DL](https://github.com/guohuiyuan/go-music-dl) | 本地音乐库和下载服务。 | AGPL-3.0；Vela 需要用户单独获取或构建，不在本仓库内分发。 |
| [music-lib](https://github.com/guohuiyuan/music-lib) | 元数据助手使用的歌词、封面和曲目目录适配库。 | AGPL-3.0；由 `mac-receiver/metadata-helper/go.mod` 声明。 |

Vela 按 AGPL-3.0 发布，以兼容整合所需的强 copyleft 条款。第三方组件的版权、来源和额外通知仍属于各自权利人；`LICENSE` 不会替代这些组件的单独许可。

公开源码仓库不附带 MacPlay 预编译运行时、Go Music DL 二进制或接收端认证材料。维护者的体验版安装包会按 MacPlay 上游的打包方式内置一组实验性认证材料；源码构建默认不带材料，只有显式设置 `VELA_AUTH_SOURCE_DIR` 才会复制该目录中的 `identity.pk8` 与 `certificate.p7b`。

MacPlay 随附的上游 NOTICE 说明，这组实验性材料源自 DiPlay 0.2.6 APK，再分发授权尚未独立确认。Vela 的体验版沿用该上游做法是为了让下载者能够直接尝试 CarPlay；这不代表 Apple/MFi 认证，也不证明材料的再分发权已经取得。公开发布者和使用者应阅读 [MacPlay 认证材料来源说明](https://github.com/Roylyl/MacPlay/blob/main/assets/authentication/SOURCE.txt)，并自行评估许可与使用风险。材料仅随应用包提供，不会单独发布；不要把设备配对记录、本机设置、Wi-Fi 密码或其他用户数据打进安装包。

CarPlay 是 Apple 的商标和 MFi 技术。本项目独立开发，与 Apple 无隶属或背书关系；不声称获得 MFi 认证。参见 [Apple MFi 计划说明](https://mfi.apple.com/en/how-it-works.html)。
