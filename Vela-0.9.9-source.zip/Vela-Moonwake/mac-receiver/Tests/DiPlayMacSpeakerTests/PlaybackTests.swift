import XCTest
@testable import DiPlayMacSpeaker

final class PlaybackTests: XCTestCase {
    func testLyricsUnicodeMultipleTagsTranslationAndOffset() {
        let lyrics = Lyrics("[ar:示例]\n[offset:-500]\n[00:01.50][00:03.000]你好 🎵\n[00:01.500]Hello\n[00:05.1]再见")
        XCTAssertEqual(lyrics.lines.count, 3)
        XCTAssertEqual(lyrics.lines[0].time, 1, accuracy: 0.001)
        XCTAssertTrue(lyrics.lines[0].text.contains("你好 🎵"))
        XCTAssertTrue(lyrics.lines[0].text.contains("Hello"))
        XCTAssertNil(lyrics.index(at: 0.9))
        XCTAssertEqual(lyrics.index(at: 1), 0)
        XCTAssertEqual(lyrics.index(at: 2.5), 1)
        XCTAssertEqual(lyrics.index(at: 100), 2)
    }

    func testPlainLyricsAndMalformedInput() {
        let lyrics = Lyrics("[ar:作者]\n第一句\n第二句\n[00:xx]无效时间")
        XCTAssertFalse(lyrics.isTimed)
        XCTAssertEqual(lyrics.plainText, "第一句\n第二句")
        XCTAssertNil(lyrics.index(at: 500))
    }
}
