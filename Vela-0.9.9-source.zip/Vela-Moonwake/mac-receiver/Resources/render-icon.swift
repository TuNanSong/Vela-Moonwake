import AppKit
let base = CommandLine.arguments[1]
let output = CommandLine.arguments[2]
func render(_ size: Int, carPlay: Bool = false) -> Data {
 let rep = NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:size,pixelsHigh:size,bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0)!
 let gc = NSGraphicsContext(bitmapImageRep: rep)!
 NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current = gc
 let c = gc.cgContext
 c.scaleBy(x:CGFloat(size)/1024,y:CGFloat(size)/1024)
 c.translateBy(x:0,y:1024); c.scaleBy(x:1,y:-1)
 // Flat artwork: no bevels, gradients, or cast shadows. CarPlay icons use
 // an opaque full-bleed canvas so transparent pixels cannot become a black
 // frame when the receiver composites the OEM icon.
 c.setFillColor(CGColor(red:1.0,green:0.985,blue:0.965,alpha:1))
 if carPlay {
  c.fill(CGRect(x:0,y:0,width:1024,height:1024))
 } else {
  c.addPath(CGPath(roundedRect:CGRect(x:100,y:100,width:824,height:824),cornerWidth:184,cornerHeight:184,transform:nil)); c.fillPath()
 }
 c.setShadow(offset:.zero,blur:0,color:nil)
 c.translateBy(x:512,y:512); c.scaleBy(x:0.86,y:0.86); c.translateBy(x:-489,y:-520)
 let p=CGMutablePath()
 p.move(to:CGPoint(x:680,y:272))
 p.addCurve(to:CGPoint(x:712,y:296),control1:CGPoint(x:696,y:268),control2:CGPoint(x:712,y:280))
 p.addLine(to:CGPoint(x:712,y:626))
 p.addCurve(to:CGPoint(x:609,y:714),control1:CGPoint(x:712,y:680),control2:CGPoint(x:660,y:714))
 p.addCurve(to:CGPoint(x:526,y:649),control1:CGPoint(x:555,y:714),control2:CGPoint(x:526,y:688))
 p.addCurve(to:CGPoint(x:648,y:578),control1:CGPoint(x:526,y:605),control2:CGPoint(x:578,y:578))
 p.addLine(to:CGPoint(x:648,y:377)); p.addLine(to:CGPoint(x:452,y:423)); p.addLine(to:CGPoint(x:452,y:680))
 p.addCurve(to:CGPoint(x:349,y:768),control1:CGPoint(x:452,y:734),control2:CGPoint(x:400,y:768))
 p.addCurve(to:CGPoint(x:266,y:703),control1:CGPoint(x:295,y:768),control2:CGPoint(x:266,y:742))
 p.addCurve(to:CGPoint(x:388,y:632),control1:CGPoint(x:266,y:659),control2:CGPoint(x:318,y:632))
 p.addLine(to:CGPoint(x:388,y:352))
 p.addCurve(to:CGPoint(x:420,y:314),control1:CGPoint(x:388,y:332),control2:CGPoint(x:400,y:318))
 p.closeSubpath()
 c.setFillColor(CGColor(red:0.96,green:0.30,blue:0.27,alpha:1)); c.addPath(p); c.fillPath()
 NSGraphicsContext.restoreGraphicsState()
 return rep.representation(using:.png,properties:[:])!
}
try render(1024).write(to:URL(fileURLWithPath:output))
let iconset=base + "/Vela.iconset"
try FileManager.default.createDirectory(atPath:iconset,withIntermediateDirectories:true)
for (name,size) in [("icon_16x16",16),("icon_16x16@2x",32),("icon_32x32",32),("icon_32x32@2x",64),("icon_128x128",128),("icon_128x128@2x",256),("icon_256x256",256),("icon_256x256@2x",512),("icon_512x512",512),("icon_512x512@2x",1024)] {try render(size).write(to:URL(fileURLWithPath:iconset + "/" + name + ".png"))}
for size in [256,512] {try render(size,carPlay:true).write(to:URL(fileURLWithPath:base + "/CarPlay-\(size).png"))}
