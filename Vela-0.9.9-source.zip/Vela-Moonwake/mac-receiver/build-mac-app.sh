#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
OUTPUT_DIR="${1:-$REPO_ROOT/dist}"
DIPLAY_APP_NAME="${DIPLAY_APP_NAME:-Vela}"
APP_PATH="$OUTPUT_DIR/$DIPLAY_APP_NAME.app"
CONTENTS_PATH="$APP_PATH/Contents"
BUILD_PATH="${VELA_SWIFT_SCRATCH_PATH:-${DIPLAY_BUILD_PATH:-$SCRIPT_DIR/.build}}"
SWIFT_PACKAGE_PATH="${VELA_SWIFT_PACKAGE_PATH:-$SCRIPT_DIR}"
MUSIC_DL_ROOT="${MUSIC_DL_ROOT:-}"
if [[ -z "${DEVELOPER_DIR:-}" && -d /Applications/Xcode-beta.app ]]; then
    export DEVELOPER_DIR=/Applications/Xcode-beta.app/Contents/Developer
fi

if [[ -z "${DIPLAY_METADATA_BINARY:-}" ]] && ! command -v go >/dev/null 2>&1; then
    echo "Go is required to build the bundled artwork and lyrics matcher." >&2
    exit 1
fi

swift build -c release --package-path "$SWIFT_PACKAGE_PATH" --scratch-path "$BUILD_PATH"

rm -rf "$APP_PATH"
mkdir -p "$CONTENTS_PATH/MacOS" "$CONTENTS_PATH/Frameworks" "$CONTENTS_PATH/Resources"
cp "$BUILD_PATH/release/DiPlayMacSpeaker" "$CONTENTS_PATH/MacOS/Vela"
if [[ -n "${DIPLAY_METADATA_BINARY:-}" ]]; then
    cp "$DIPLAY_METADATA_BINARY" "$CONTENTS_PATH/MacOS/diplay-metadata"
else
    (
        cd "$SCRIPT_DIR/metadata-helper"
        CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 go build -mod=mod -trimpath -ldflags="-s -w" \
            -o "$CONTENTS_PATH/MacOS/diplay-metadata" .
    )
fi
cp "$SCRIPT_DIR/Info.plist" "$CONTENTS_PATH/Info.plist"
cp "$SCRIPT_DIR/Resources/Vela-Coral.icns" "$CONTENTS_PATH/Resources/Vela-Coral.icns"
cp "$SCRIPT_DIR/Resources/MacPlay-LICENSE.txt" "$CONTENTS_PATH/Resources/MacPlay-LICENSE.txt"
cp "$REPO_ROOT/licenses/DiPlay-LICENSE.txt" "$CONTENTS_PATH/Resources/DiPlay-LICENSE.txt"
cp "$REPO_ROOT/LICENSE" "$CONTENTS_PATH/Resources/Vela-LICENSE.txt"
cp "$REPO_ROOT/licenses/Go-Music-DL-LICENSE.txt" "$CONTENTS_PATH/Resources/Go-Music-DL-LICENSE.txt"
if [[ -n "${MUSIC_DL_BINARY:-}" ]]; then
    cp "$MUSIC_DL_BINARY" "$CONTENTS_PATH/MacOS/music-dl"
    chmod +x "$CONTENTS_PATH/MacOS/music-dl"
    if [[ -f "$MUSIC_DL_ROOT/LICENSE" ]]; then
        cp "$MUSIC_DL_ROOT/LICENSE" "$CONTENTS_PATH/Resources/Go-Music-DL-LICENSE.txt"
    elif [[ -f "$(dirname "$MUSIC_DL_BINARY")/LICENSE" ]]; then
        cp "$(dirname "$MUSIC_DL_BINARY")/LICENSE" "$CONTENTS_PATH/Resources/Go-Music-DL-LICENSE.txt"
    fi
elif [[ -d "$MUSIC_DL_ROOT" ]] && command -v go >/dev/null 2>&1; then
    (
        cd "$MUSIC_DL_ROOT"
        CGO_ENABLED=0 GOOS=darwin GOARCH=arm64 go build -trimpath -ldflags="-s -w" \
            -o "$CONTENTS_PATH/MacOS/music-dl" ./cmd/music-dl
    )
    cp "$MUSIC_DL_ROOT/LICENSE" "$CONTENTS_PATH/Resources/Go-Music-DL-LICENSE.txt" 2>/dev/null || true
    chmod +x "$CONTENTS_PATH/MacOS/music-dl"
else
    echo "Go Music DL server not bundled. Set MUSIC_DL_BINARY or install Go and set MUSIC_DL_ROOT." >&2
    exit 1
fi
bash "$SCRIPT_DIR/build-carplay-service.sh" "$APP_PATH"
# Finder and file-provider metadata on reused binaries can make codesign reject
# an otherwise valid app bundle. Clear attributes from every bundle entry.
find "$APP_PATH" -exec xattr -c {} \; 2>/dev/null || true
# A certificate-backed requirement stays stable across local rebuilds, whereas
# ad-hoc signatures identify each build by its code hash and invalidate TCC grants.
VELA_SIGNER="${VELA_CODE_SIGN_IDENTITY:--}"
if [[ -z "${VELA_CODE_SIGN_IDENTITY:-}" ]]; then
    VELA_DEVELOPMENT_COUNT="$(security find-identity -v -p codesigning | awk '/"Apple Development:/ { count++ } END { print count+0 }')"
    if [[ "$VELA_DEVELOPMENT_COUNT" == 1 ]]; then VELA_SIGNER="Apple Development"; fi
fi
codesign --force --deep --sign "$VELA_SIGNER" "$APP_PATH"
codesign --verify --deep --strict "$APP_PATH"
ditto -c -k --norsrc --keepParent "$APP_PATH" "$OUTPUT_DIR/$DIPLAY_APP_NAME.zip"

echo "Created $APP_PATH"
