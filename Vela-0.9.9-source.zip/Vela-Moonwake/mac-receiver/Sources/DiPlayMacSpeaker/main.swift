import AppKit
import Foundation

struct NowPlaying {
    var title: String? = nil
    var artist: String? = nil
    var album: String? = nil
    var durationMillis: Int64? = nil
    var elapsedMillis: Int64? = nil
    var playing = false

    init(title: String? = nil, artist: String? = nil, album: String? = nil,
         durationMillis: Int64? = nil, elapsedMillis: Int64? = nil, playing: Bool = false) {
        self.title = title
        self.artist = artist
        self.album = album
        self.durationMillis = durationMillis
        self.elapsedMillis = elapsedMillis
        self.playing = playing
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var statusItem: NSStatusItem!
    private let popover = NSPopover()
    private let previewMode = CommandLine.arguments.contains("--preview-idle")
    private let playerViewController = MiniPlayerViewController()
    private var universalPlayerWindow: UniversalPlayerWindowController?
    private var musicWebProcess: Process?
    private var musicWebURL: URL?
    private var progressTimer: Timer?
    private var lastStatus = ""
    @MainActor private lazy var carPlayFeed = CarPlayNowPlayingFeed()
    @MainActor private lazy var carPlayControl = CarPlayControlClient()
    @MainActor private lazy var carPlayBackend = CarPlayBackend()
    private var carPlayPhoneID = ""
    private let metadataResolver = MetadataResolver()
    private let lyricsResolver = MetadataResolver()
    private var metadataArtworkKey: String?
    private var metadataArtworkLookedUpAt: Date?
    private var metadataLyricsKey: String?
    private var pendingCarPlayLyricsKey: String?
    private var pendingCarPlayLyrics: DispatchWorkItem?
    private var lyricsTrackContext = ""
    private var previousCarPlayTitle = ""
    private var carPlayTitleChanges = 0
    private var carPlayTitleChangeWindow = Date()
    private var carPlayTitleLooksLikeLyrics = false

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        buildApplicationMenu()
        buildMenuBarItem()
        buildMiniPlayer()
        carPlayFeed.onEvent = { [weak self] event in
            guard let self, self.universalPlayerWindow?.model.carPlayEngineRunning == true else { return }
            if let phone = event["phoneId"] as? String, !self.carPlayPhoneID.isEmpty,
               phone.replacingOccurrences(of:"-",with:":").lowercased() != self.carPlayPhoneID.replacingOccurrences(of:"-",with:":").lowercased() { return }
            if self.universalPlayerWindow == nil { self.showUniversalPlayer() }
            self.universalPlayerWindow?.model.receiveCarPlay(event)
            if event["type"] as? String == "albumart",
               let encoded = event["dataB64"] as? String, let data = Data(base64Encoded: encoded),
               let image = NSImage(data: data) {
                if self.universalPlayerWindow?.model.source == "iPhone CarPlay" {
                    self.universalPlayerWindow?.model.artwork = image
                    self.playerViewController.updateArtwork(image)
                }
            } else if event["type"] as? String == "nowplaying" {
                guard let model = self.universalPlayerWindow?.model else { return }
                guard model.source == "iPhone CarPlay" else { return }
                let info = NowPlaying(
                    title: model.title,
                    artist: model.artist,
                    album: model.album,
                    durationMillis: Int64(model.duration * 1000),
                    elapsedMillis: Int64(model.elapsed * 1000),
                    playing: model.playing
                )
                self.updateCarPlayArtwork(for: info)
                self.updateCarPlayLyrics(for: info, trackID: model.carPlayMetadataTrackID)
            }
        }
        carPlayControl.onStatus = { [weak self] value in
            guard let self, let model = self.universalPlayerWindow?.model else { return }
            model.carPlayControlReady = value != nil
            if value != nil || !self.carPlayBackend.isRunning { model.carPlayBackendStarting=false }
            model.macPlayRunning = value != nil || self.carPlayBackend.isRunning
            guard let value else {
                if !model.macPlayRunning { model.carPlayConnected = false }
                return
            }
            self.carPlayPhoneID = value["phoneId"] as? String ?? ""
            model.carPlayConnected = value["connected"] as? Bool ?? false
            model.carPlayEngineRunning = value["running"] as? Bool ?? false
            model.carPlayEmbedded = value["embeddedVideo"] as? Bool ?? false
            model.carPlayStatus = value["status"] as? String ?? ""
            model.carPlayDetail = value["detail"] as? String ?? ""
            model.carPlayUSBCount = value["usbCount"] as? Int ?? 0
            if !model.carPlayAudioEditing {
                model.carPlayVolume=value["volume"] as? Double ?? model.carPlayVolume
                model.carPlayCallVolume=value["callVolume"] as? Double ?? model.carPlayCallVolume
                model.carPlayAudioEnabled=value["audioEnabled"] as? Bool ?? model.carPlayAudioEnabled
            }
            if let phones = value["phones"] as? [[String: Any]] {
                model.carPlayPhones = phones.compactMap { phone in
                    guard let id = phone["id"] as? String, let name = phone["name"] as? String else { return nil }
                    return PlayerHubModel.PhoneOption(id: id, name: name)
                }
            }
            if !model.carPlayConfigurationEdited {
                model.carPlaySelectedPhone = value["selectedPhone"] as? String ?? ""
                model.carPlayWireless = value["wireless"] as? Bool ?? false
            }
            if model.carPlayConnected {
                var event = value; event["type"] = "nowplaying"
                model.receiveCarPlay(event)
            } else if model.source == "iPhone CarPlay" { model.playing = false }
        }
        carPlayFeed.start(); carPlayControl.start()
        startMusicWebService()
        if previewMode {
            Task { @MainActor in self.showUniversalPlayer() }
        } else {
            setStatus("等待 iPhone CarPlay 或音乐库播放")
        }
        let timer = Timer(timeInterval: 0.25, repeats: true) { [weak self] _ in
            guard let self else { return }
            if self.popover.isShown { self.playerViewController.refreshProgress() }
            MainActor.assumeIsolated { self.universalPlayerWindow?.model.refreshPlaybackClock() }
        }
        timer.tolerance = 0.05
        RunLoop.main.add(timer, forMode: .common)
        progressTimer = timer
        if !previewMode { DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { self.showUniversalPlayer();self.carPlayBackend.start() } }
    }

    func applicationWillTerminate(_ notification: Notification) {
        progressTimer?.invalidate()
        carPlayFeed.stop(); carPlayControl.stop(); carPlayControl.stopEmbeddedReceiver()
        universalPlayerWindow?.model.carPlayVideo.stop()
        carPlayBackend.stop()
        metadataResolver.cancel()
        pendingCarPlayLyrics?.cancel()
        lyricsResolver.cancel()
        musicWebProcess?.terminate()
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        showUniversalPlayer()
        return true
    }

    private func buildApplicationMenu() {
        let main = NSMenu()
        let appItem = NSMenuItem(); let appMenu = NSMenu(title: "Vela")
        appMenu.addItem(withTitle: "关于 Vela", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        appMenu.addItem(.separator())
        let settings = NSMenuItem(title: "设置…", action: #selector(openSettingsMenu), keyEquivalent: ",")
        settings.target = self; appMenu.addItem(settings)
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "隐藏 Vela", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        appMenu.addItem(withTitle: "退出 Vela", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu; main.addItem(appItem)
        let editItem = NSMenuItem(); let edit = NSMenu(title: "编辑")
        for (title, action, key) in [("撤销", "undo:", "z"), ("剪切", "cut:", "x"), ("复制", "copy:", "c"), ("粘贴", "paste:", "v"), ("全选", "selectAll:", "a")] {
            edit.addItem(withTitle: title, action: Selector(action), keyEquivalent: key)
        }
        editItem.submenu = edit; main.addItem(editItem)
        let windowItem = NSMenuItem(); let windowMenu = NSMenu(title: "窗口")
        windowMenu.addItem(withTitle: "最小化", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        windowMenu.addItem(withTitle: "关闭窗口", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
        windowItem.submenu = windowMenu; main.addItem(windowItem); NSApp.windowsMenu = windowMenu
        NSApp.mainMenu = main
    }
    @objc private func openSettingsMenu() {
        Task { @MainActor in self.showUniversalPlayer(); self.universalPlayerWindow?.model.section = .settings }
    }

    private func buildMenuBarItem() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        let image = NSImage(systemSymbolName: "music.note", accessibilityDescription: "Vela")
        image?.isTemplate = true
        statusItem.button?.image = image
        statusItem.button?.toolTip = "Vela"
        statusItem.button?.target = self
        statusItem.button?.action = #selector(togglePopover)
    }

    private func buildMiniPlayer() {
        popover.behavior = .transient
        popover.animates = !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion
        popover.contentSize = NSSize(width: PlayerLayout.width, height: PlayerLayout.compactHeight)
        popover.contentViewController = playerViewController
        playerViewController.onSourceCommand = { [weak self] action in
            Task { @MainActor in
                guard let self, let model = self.universalPlayerWindow?.model else { return }
                model.perform(action)
            }
        }
        playerViewController.onOpenUniversalPlayer = { [weak self] in
            Task { @MainActor in self?.showUniversalPlayer() }
        }
        playerViewController.onQuit = { NSApp.terminate(nil) }
        playerViewController.onCopyDiagnostics = { [weak self] in Task { @MainActor in self?.copyDiagnostics() } }
        playerViewController.onLyricsVisibilityChanged = { [weak self] expanded in
            self?.popover.contentSize = NSSize(width: PlayerLayout.width, height: expanded ? PlayerLayout.expandedHeight : PlayerLayout.compactHeight)
        }
    }

    @objc private func togglePopover() {
        if popover.isShown { popover.performClose(nil) } else { showPanel() }
    }

    private func showPanel() {
        guard let button = statusItem.button else { return }
        playerViewController.refreshProgress()
        popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
        popover.contentViewController?.view.window?.makeKey()
    }

    @MainActor private func showUniversalPlayer() {
        if universalPlayerWindow == nil {
            let controller = UniversalPlayerWindowController()
            self.carPlayBackend.onError = { [weak controller] text in controller?.model.macPlayLaunchError=text;controller?.model.carPlayBackendStarting=false }
            controller.model.onOpenCarPlaySettings = { [weak self, weak controller] present in
                guard let self, let model=controller?.model else { return }
                model.macPlayLaunchError=nil
                if !model.carPlayControlReady { model.carPlayBackendStarting=true;self.carPlayBackend.start() }
                guard present, model.carPlayControlReady else { return }
                self.carPlayControl.request("configuration") { response in
                    if let data=response?["configuration"], let bytes=try? JSONSerialization.data(withJSONObject:data), let config=try? JSONDecoder().decode(CarPlayConfiguration.self,from:bytes) {
                        model.carPlayConfiguration=config;model.projectionDisplayID=config.displayID;model.carPlaySettingsPresented=true
                    } else { model.playbackError="接收端暂时未就绪，请稍后打开设置。" }
                }
            }
            controller.model.onSaveCarPlaySettings = { [weak self, weak controller] draft,password,clear,completion in
                self?.carPlayControl.request("configure", properties:draft.request(password:password,clearPassword:clear)) { response in
                    if response?["ok"] as? Bool == true { controller?.model.projectionDisplayID=draft.displayID }
                    completion(response?["ok"] as? Bool == true ? nil : response?["error"] as? String ?? "设置未保存，请重试")
                }
            }
            controller.model.onCarPlayAudio = { [weak self,weak controller] volume,callVolume,enabled in
                self?.carPlayControl.audio(volume:volume,callVolume:callVolume,enabled:enabled) { failure in
                    if let failure {controller?.model.playbackError=failure}
                }
            }
            controller.model.carPlayVideo.start()
            controller.model.carPlayVideo.onTouch = { [weak self] x, y, down in self?.carPlayControl.touch(x:x,y:y,down:down) }
            controller.model.onMiniPlayerChanged = { [weak self, weak model = controller.model] in
                guard let self, let model else { return }
                self.syncMiniPlayer(from: model)
            }
            controller.model.onArtworkChanged = { [weak self] image in self?.playerViewController.updateArtwork(image) }
            controller.model.onCarPlayAction = { [weak self, weak controller] action, value in
                self?.carPlayControl.request(action, value: value) { response in
                    guard response?["ok"] as? Bool == true else {
                        controller?.model.playbackError = response?["error"] as? String ?? "iPhone 接收端未连接，请打开 CarPlay 页面"
                        return
                    }
                    if action == "stop" { controller?.model.carPlayVideo.clearPresentedFrame() }
                }
            }
            controller.model.onCarPlayConnect = { [weak self, weak controller] phone, wireless in
                controller?.model.playbackError = nil
                controller?.model.carPlayConnecting = true
                self?.carPlayControl.request("connect", properties: ["phone":phone,"wireless":wireless,"embeddedVideo":true]) { response in
                    controller?.model.carPlayConnecting = false
                    if response?["ok"] as? Bool != true { controller?.model.playbackError = response?["error"] as? String ?? "无法连接接收端" }
                }
            }
            universalPlayerWindow = controller
            controller.model.localSiteURL = musicWebURL
        }
        universalPlayerWindow?.model.updateStatus(lastStatus)
        universalPlayerWindow?.show()
    }

    @MainActor private func startMusicWebService() {
        let executable = Bundle.main.bundleURL.appendingPathComponent("Contents/MacOS/music-dl")
        guard FileManager.default.isExecutableFile(atPath: executable.path) else { return }
        let storedPort = UserDefaults.standard.integer(forKey: "Vela.musicServicePort")
        let port = CommandLine.arguments.contains("--verify-playback") ? Int.random(in: 38000...48000) : (storedPort > 0 ? storedPort : 43973)
        if !CommandLine.arguments.contains("--verify-playback") { UserDefaults.standard.set(port, forKey: "Vela.musicServicePort") }
        let process = Process()
        process.executableURL = executable
        process.arguments = ["web", "--desktop", "--port", String(port)]
        let dataDirectory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("DiPlay Music", isDirectory: true)
        try? FileManager.default.createDirectory(at: dataDirectory, withIntermediateDirectories: true)
        process.currentDirectoryURL = dataDirectory
        process.standardOutput = FileHandle.nullDevice
        process.standardError = FileHandle.nullDevice
        do {
            try process.run()
            musicWebProcess = process
            pollMusicSite(port: port, attemptsRemaining: 70)
        } catch {
            universalPlayerWindow?.model.updateStatus("音乐下载服务启动失败：\(error.localizedDescription)")
        }
    }

    @MainActor private func pollMusicSite(port: Int, attemptsRemaining: Int) {
        guard attemptsRemaining > 0, musicWebProcess?.isRunning == true else { return }
        guard let health = URL(string: "http://127.0.0.1:\(port)/music/healthz") else { return }
        URLSession.shared.dataTask(with: health) { [weak self] _, response, _ in
            guard let self else { return }
            if let response = response as? HTTPURLResponse, (200..<300).contains(response.statusCode) {
                DispatchQueue.main.async {
                    let root = URL(string: "http://127.0.0.1:\(port)/music/")
                    self.musicWebURL = root
                    self.universalPlayerWindow?.model.localSiteURL = root
                }
                return
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                self.pollMusicSite(port: port, attemptsRemaining: attemptsRemaining - 1)
            }
        }.resume()
    }

    @MainActor private func copyDiagnostics() {
        let model = universalPlayerWindow?.model
        let report = [
            "Vela \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "")",
            "CarPlay: \(model?.carPlayConnectionMessage ?? "未启动")",
            "接收端: \(model?.carPlayStatus ?? "未知")",
            "音乐库: \(model?.websiteReady == true ? "已就绪" : "未就绪")",
            "播放来源: \(model?.source ?? "未知")",
            "播放状态: \(model?.playing == true ? "播放中" : "已暂停/无播放")"
        ].joined(separator: "\n")
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(report, forType: .string)
    }

    private func updateCarPlayArtwork(for info: NowPlaying) {
        let album = info.album?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let artist = info.artist?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !album.isEmpty else { return }
        let key = [artist, album].joined(separator: "\u{1f}").lowercased()
        if key == metadataArtworkKey,
           let lastLookup = metadataArtworkLookedUpAt,
           Date().timeIntervalSince(lastLookup) < 300 { return }
        metadataArtworkKey = key
        metadataArtworkLookedUpAt = Date()
        metadataResolver.resolveArtwork(artist: artist, album: album) { [weak self] cover in
            Task { @MainActor in
                guard let model = self?.universalPlayerWindow?.model,
                      model.source == "iPhone CarPlay",
                      model.artist.trimmingCharacters(in: .whitespacesAndNewlines) == artist,
                      model.album.trimmingCharacters(in: .whitespacesAndNewlines) == album,
                      model.artwork == nil,
                      let cover,
                      let image = NSImage(data: cover) else { return }
                self?.playerViewController.updateOnlineMetadata(cover: cover, lyrics: nil)
                model.applyMatchedArtwork(image, artist: artist, album: album)
            }
        }
    }

    @MainActor private func updateCarPlayLyrics(for info: NowPlaying, trackID: String?) {
        let title = info.title?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let artist = info.artist?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let album = info.album?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard title.count >= 2, !artist.isEmpty else { return }
        let context = [trackID ?? "", artist, album, String((info.durationMillis ?? 0) / 1000)]
            .joined(separator: "\u{1f}").lowercased()
        if context != lyricsTrackContext {
            lyricsTrackContext = context
            previousCarPlayTitle = title
            carPlayTitleChanges = 0
            carPlayTitleChangeWindow = Date()
            carPlayTitleLooksLikeLyrics = false
            metadataLyricsKey = nil
            pendingCarPlayLyrics?.cancel()
            pendingCarPlayLyricsKey = nil
            lyricsResolver.cancel()
        } else if title != previousCarPlayTitle {
            let now = Date()
            if now.timeIntervalSince(carPlayTitleChangeWindow) > 30 {
                carPlayTitleChangeWindow = now
                carPlayTitleChanges = 0
            }
            carPlayTitleChanges += 1
            previousCarPlayTitle = title
            if carPlayTitleChanges >= 2 {
                // Three distinct titles for one stable CarPlay track usually mean
                // the phone app is scrolling lyric lines through the title field.
                carPlayTitleLooksLikeLyrics = true
                pendingCarPlayLyrics?.cancel()
                pendingCarPlayLyrics = nil
                pendingCarPlayLyricsKey = nil
                lyricsResolver.cancel()
                self.universalPlayerWindow?.model.setLyricsMatching(false)
            }
        }
        guard !carPlayTitleLooksLikeLyrics else { return }
        let key = [title, artist, album, String((info.durationMillis ?? 0) / 1000)]
            .joined(separator: "\u{1f}").lowercased()
        guard key != metadataLyricsKey, key != pendingCarPlayLyricsKey else { return }

        // CarPlay apps such as NetEase may publish each lyric line as a changing
        // title. Debounce title changes so those lines are not mistaken for a song.
        pendingCarPlayLyrics?.cancel()
        lyricsResolver.cancel()
        pendingCarPlayLyricsKey = key
        let work = DispatchWorkItem { [weak self] in
            Task { @MainActor [weak self] in
                guard let self else { return }
                self.pendingCarPlayLyricsKey = nil
                guard let model = self.universalPlayerWindow?.model,
                      model.source == "iPhone CarPlay",
                      model.title.trimmingCharacters(in: .whitespacesAndNewlines) == title,
                      model.artist.trimmingCharacters(in: .whitespacesAndNewlines) == artist,
                      model.album.trimmingCharacters(in: .whitespacesAndNewlines) == album else { return }
                self.metadataLyricsKey = key
                model.setLyricsMatching(true)
                self.lyricsResolver.resolveLyrics(title: title, artist: artist, album: album,
                                                  durationMillis: info.durationMillis ?? 0) { [weak self] lyrics in
                    Task { @MainActor [weak self] in
                        guard let self,
                              let model = self.universalPlayerWindow?.model else { return }
                        guard model.source == "iPhone CarPlay",
                              model.title.trimmingCharacters(in: .whitespacesAndNewlines) == title,
                              model.artist.trimmingCharacters(in: .whitespacesAndNewlines) == artist,
                              model.album.trimmingCharacters(in: .whitespacesAndNewlines) == album else {
                            if self.metadataLyricsKey == key {
                                self.metadataLyricsKey = nil
                                model.setLyricsMatching(false)
                            }
                            return
                        }
                        guard let lyrics, !lyrics.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                            model.setLyricsMatching(false, failed: true)
                            return
                        }
                        model.applyMatchedLyrics(lyrics, for: info)
                    }
                }
            }
        }
        pendingCarPlayLyrics = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 4, execute: work)
    }

    @MainActor private func syncMiniPlayer(from model: PlayerHubModel) {
        let info = NowPlaying(title: model.title, artist: model.artist, album: model.album,
                              durationMillis: Int64(model.duration * 1000),
                              elapsedMillis: Int64(model.elapsed * 1000), playing: model.playing)
        let isConnected = model.source == "iPhone CarPlay" ? model.carPlayConnected : model.hasLibraryTrack
        playerViewController.update(nowPlaying: info,
                                    status: isConnected ? "Connected" : "Disconnected",
                                    source: model.source)
        playerViewController.updateArtwork(model.artwork)
        playerViewController.updateOnlineMetadata(cover: nil, lyrics: model.miniLyrics)
        if model.source == "iPhone CarPlay" {
            let status = model.lyricsMatching ? "正在匹配歌词…" : model.lyricsMatchFailed ? "暂未匹配到歌词" : "歌词由 CarPlay 曲目标题同步显示"
            playerViewController.updateLyricsStatus(status)
        }
    }

    private func setStatus(_ text: String) {
        DispatchQueue.main.async {
            guard self.lastStatus != text else { return }
            self.lastStatus = text
            self.statusItem?.button?.toolTip = "Vela · 点击打开播放面板"
            self.playerViewController.update(status: text)
            self.universalPlayerWindow?.model.updateStatus(text)
        }
    }


}

let application = NSApplication.shared
let delegate = AppDelegate()
application.delegate = delegate
application.run()
