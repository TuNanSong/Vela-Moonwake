import AppKit

enum PlayerLayout {
    static let width: CGFloat = 370
    static let compactHeight: CGFloat = 276
    static let expandedHeight: CGFloat = 416
}

final class TopDownView: NSView { override var isFlipped: Bool { true } }

private final class ProgressLine: NSView {
    var fraction = 0.0 { didSet { if fraction != oldValue { needsDisplay = true } } }
    override func draw(_ dirtyRect: NSRect) {
        NSColor.labelColor.withAlphaComponent(0.12).setFill()
        NSBezierPath(roundedRect: bounds, xRadius: 1.5, yRadius: 1.5).fill()
        let fill = NSRect(x: 0, y: 0, width: bounds.width * max(0, min(1, fraction)), height: bounds.height)
        NSColor(calibratedRed: 0.88, green: 0.27, blue: 0.22, alpha: 0.92).setFill()
        NSBezierPath(roundedRect: fill, xRadius: 1.5, yRadius: 1.5).fill()
    }
    override func viewDidChangeEffectiveAppearance() { needsDisplay = true }
}

private final class StatusDot: NSView {
    var connected = false { didSet { needsDisplay = true } }
    override func draw(_ dirtyRect: NSRect) {
        (connected ? NSColor.systemGreen : NSColor.tertiaryLabelColor).setFill()
        NSBezierPath(ovalIn: bounds).fill()
    }
}

final class MiniPlayerViewController: NSViewController {
    var onSourceCommand: ((String) -> Void)?
    var onQuit: (() -> Void)?
    var onLyricsVisibilityChanged: ((Bool) -> Void)?
    var onCopyDiagnostics: (() -> Void)?
    var onOpenUniversalPlayer: (() -> Void)?

    private let content = TopDownView()
    private let artworkView = NSImageView()
    private let placeholder = NSImageView()
    private let titleLabel = NSTextField(labelWithString: "等待播放")
    private let detailLabel = NSTextField(labelWithString: "连接 iPhone 或打开音乐库开始播放")
    private let elapsedLabel = NSTextField(labelWithString: "0:00")
    private let remainingLabel = NSTextField(labelWithString: "−:−−")
    private let progress = ProgressLine()
    private let statusLabel = NSTextField(labelWithString: "正在启动…")
    private let connectionDot = StatusDot()
    private let playButton = NSButton()
    private let previousButton = NSButton()
    private let nextButton = NSButton()
    private let moreButton = NSButton()
    private let lyricsButton = NSButton()
    private let lyricArea = TopDownView()
    private let lyricLabels = (0..<3).map { _ in NSTextField(wrappingLabelWithString: "") }
    private let plainScroll = NSScrollView()
    private let plainLyrics = NSTextView()
    private(set) var lyricsExpanded = false
    private var nowPlaying = NowPlaying()
    private var elapsedUpdatedAt = ProcessInfo.processInfo.systemUptime
    private var connected = false
    private var lyricData = Lyrics("")
    private var lyricState = "播放歌曲后显示歌词"
    private var lastLyricIndex = Int.min
    private var currentTrackKey = ""
    private var currentArtworkKey = ""
    private var currentSource = ""

    override func loadView() {
        let size = NSSize(width: PlayerLayout.width, height: PlayerLayout.compactHeight)
        content.frame = NSRect(origin: .zero, size: size)
        // NSPopover supplies the native material, arrow, corner mask and shadow.
        // Keep the content transparent so there is exactly one exterior surface.
        view = content

        let art = NSView(frame: NSRect(x: 25, y: 20, width: 64, height: 64))
        art.wantsLayer = true
        art.layer?.cornerRadius = 13
        art.layer?.masksToBounds = true
        art.layer?.backgroundColor = NSColor.gray.withAlphaComponent(0.12).cgColor
        artworkView.frame = art.bounds
        artworkView.imageScaling = .scaleProportionallyUpOrDown
        artworkView.setAccessibilityLabel("专辑封面")
        placeholder.frame = NSRect(x: 18, y: 18, width: 28, height: 28)
        placeholder.image = NSImage(systemSymbolName: "music.note", accessibilityDescription: nil)
        placeholder.contentTintColor = .secondaryLabelColor
        art.addSubview(artworkView)
        art.addSubview(placeholder)
        content.addSubview(art)

        label(titleLabel, frame: NSRect(x: 102, y: 27, width: 202, height: 22), size: 15, weight: .semibold)
        label(detailLabel, frame: NSRect(x: 102, y: 53, width: 238, height: 18), size: 11.5, secondary: true)
        label(elapsedLabel, frame: NSRect(x: 26, y: 190, width: 100, height: 15), size: 10.5, secondary: true)
        label(remainingLabel, frame: NSRect(x: 244, y: 190, width: 100, height: 15), size: 10.5, secondary: true)
        remainingLabel.alignment = .right
        elapsedLabel.font = .monospacedDigitSystemFont(ofSize: 10.5, weight: .regular)
        remainingLabel.font = elapsedLabel.font
        progress.frame = NSRect(x: 26, y: 179, width: 318, height: 3)
        progress.setAccessibilityElement(true)
        progress.setAccessibilityLabel("播放进度")
        content.addSubview(progress)

        control(previousButton, symbol: "backward.end.fill", label: "上一曲", frame: NSRect(x: 83, y: 102, width: 40, height: 40), action: #selector(previousTrack), size: 17)
        control(nextButton, symbol: "forward.end.fill", label: "下一曲", frame: NSRect(x: 247, y: 102, width: 40, height: 40), action: #selector(nextTrack), size: 17)
        control(playButton, symbol: "play.fill", label: "播放", frame: NSRect(x: 159, y: 96, width: 52, height: 52), action: #selector(togglePlayback), size: 19)
        playButton.wantsLayer = true
        playButton.layer?.cornerRadius = 26
        playButton.layer?.masksToBounds = true
        playButton.layer?.backgroundColor = NSColor(calibratedRed: 0.88, green: 0.27, blue: 0.22, alpha: 1).cgColor
        playButton.contentTintColor = .white
        playButton.keyEquivalent = " "
        playButton.keyEquivalentModifierMask = []
        control(moreButton, symbol: "ellipsis", label: "更多选项", frame: NSRect(x: 312, y: 25, width: 32, height: 30), action: #selector(showMenu(_:)), size: 16)
        moreButton.contentTintColor = .secondaryLabelColor
        control(lyricsButton, symbol: "text.bubble", label: "显示歌词", frame: .zero, action: #selector(toggleLyrics), size: 13)
        lyricsButton.title = " 歌词"
        lyricsButton.font = .systemFont(ofSize: 11.5)
        lyricsButton.attributedTitle = NSAttributedString(string: " 歌词", attributes: [.foregroundColor: NSColor.secondaryLabelColor, .font: NSFont.systemFont(ofSize: 11.5)])
        lyricsButton.imagePosition = .imageLeading
        lyricsButton.contentTintColor = .secondaryLabelColor
        label(statusLabel, frame: .zero, size: 11, secondary: true)
        content.addSubview(connectionDot)

        lyricArea.frame = NSRect(x: 26, y: 233, width: 318, height: 130)
        lyricArea.isHidden = true
        for (index, line) in lyricLabels.enumerated() {
            line.frame = NSRect(x: 0, y: CGFloat(index) * 40, width: 318, height: 37)
            line.font = .systemFont(ofSize: index == 1 ? 17 : 14, weight: index == 1 ? .semibold : .regular)
            line.alignment = .center
            line.textColor = index == 1 ? .labelColor : .secondaryLabelColor
            line.maximumNumberOfLines = 2
            line.lineBreakMode = .byTruncatingTail
            lyricArea.addSubview(line)
        }
        plainScroll.frame = lyricArea.bounds
        plainScroll.drawsBackground = false
        plainScroll.hasVerticalScroller = true
        plainScroll.scrollerStyle = .overlay
        plainScroll.autohidesScrollers = true
        plainLyrics.isEditable = false
        plainLyrics.isSelectable = true
        plainLyrics.drawsBackground = false
        plainLyrics.font = .systemFont(ofSize: 14)
        plainLyrics.textColor = .secondaryLabelColor
        plainLyrics.alignment = .center
        plainLyrics.textContainerInset = NSSize(width: 8, height: 8)
        plainLyrics.isVerticallyResizable = true
        plainLyrics.isHorizontallyResizable = false
        plainLyrics.autoresizingMask = [.width]
        plainLyrics.textContainer?.widthTracksTextView = true
        plainLyrics.frame = NSRect(x: 0, y: 0, width: 318, height: 130)
        plainScroll.documentView = plainLyrics
        lyricArea.addSubview(plainScroll)
        content.addSubview(lyricArea)
        placeFooter()
        refreshControls()
        renderLyrics(force: true)
    }

    private func placeFooter() {
        let y: CGFloat = lyricsExpanded ? 382 : 242
        statusLabel.frame = NSRect(x: 42, y: y, width: 235, height: 18)
        connectionDot.frame = NSRect(x: 27, y: y + 5, width: 7, height: 7)
        lyricsButton.frame = NSRect(x: 278, y: y - 4, width: 70, height: 26)
    }

    func update(nowPlaying: NowPlaying? = nil, status: String? = nil, source: String? = nil) {
        _ = view
        if let source, currentSource != source {
            currentSource = source
            resetTrackLyrics()
        }
        if let info = nowPlaying {
            let trackKey = [info.title ?? "", info.artist ?? "", info.album ?? ""].joined(separator: "\u{1f}")
            if !currentTrackKey.isEmpty, currentTrackKey != trackKey { resetTrackLyrics() }
            let artworkKey = [info.artist ?? "", info.album ?? ""]
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
                .joined(separator: "\u{1f}")
            if currentArtworkKey != artworkKey {
                currentArtworkKey = artworkKey
                updateArtwork(nil)
            }
            currentTrackKey = trackKey
            self.nowPlaying = info
            elapsedUpdatedAt = ProcessInfo.processInfo.systemUptime
            titleLabel.stringValue = info.title?.isEmpty == false ? info.title! : "等待播放"
            let details = [info.artist, info.album].compactMap { $0 }.filter { !$0.isEmpty }
            detailLabel.stringValue = details.isEmpty ? "等待 CarPlay 或音乐库播放" : details.joined(separator: " · ")
            titleLabel.toolTip = info.title
            detailLabel.toolTip = details.joined(separator: " · ")
        }
        if let status {
            let lower = status.lowercased()
            if lower.contains("disconnected") || lower.contains("stopped") || lower.contains("ready") { connected = false }
            else if lower.contains("connected") || lower.contains("receiving") { connected = true }
            if lower.contains("turn on bluetooth") { statusLabel.stringValue = "请开启蓝牙" }
            else if lower.contains("could not") || lower.contains("invalid") || lower.contains("error") { statusLabel.stringValue = "连接异常 · 更多中可重启" }
            else if lower.contains("buffering") { statusLabel.stringValue = "正在缓冲…" }
            else {
                let sourceName = source ?? ""
                let shortName = sourceName == "iPhone CarPlay" ? "CarPlay" : sourceName == "音乐库" ? "音乐库" : ""
                statusLabel.stringValue = connected ? (shortName.isEmpty ? "已连接" : "\(shortName) · 已连接") : "等待连接"
            }
            connectionDot.connected = connected
            if !connected {
                self.nowPlaying.elapsedMillis = currentElapsed
                self.nowPlaying.playing = false
            }
        }
        refreshControls()
        refreshProgress()
    }

    private func refreshControls() {
        let symbol = nowPlaying.playing ? "pause.fill" : "play.fill"
        playButton.image = NSImage(systemSymbolName: symbol, accessibilityDescription: nil)
        playButton.setAccessibilityLabel(nowPlaying.playing ? "暂停" : "播放")
        playButton.toolTip = nowPlaying.playing ? "暂停（空格）" : "播放（空格）"
        playButton.alphaValue = connected ? 1 : 0.55
        for button in [playButton, previousButton, nextButton] { button.isEnabled = connected }
    }

    func updateArtwork(_ image: NSImage?) {
        guard let image else {
            artworkView.image = nil
            placeholder.isHidden = false
            return
        }
        artworkView.image = image
        placeholder.isHidden = true
    }

    private func resetTrackLyrics() {
        lyricData = Lyrics("")
        lyricState = currentSource == "iPhone CarPlay" ? "歌词由 CarPlay 曲目标题同步显示" : "暂未找到歌词"
        lastLyricIndex = Int.min
        renderLyrics(force: true)
    }

    func updateOnlineMetadata(cover: Data?, lyrics: String?) {
        if let cover, let image = NSImage(data: cover) {
            artworkView.image = image
            placeholder.isHidden = true
        }
        // Cover and lyrics arrive independently; nil means keep the previous value.
        if let lyrics, lyricData.rawValue != lyrics {
            lyricData = Lyrics(lyrics)
            lyricState = lyrics.isEmpty && currentSource == "iPhone CarPlay"
                ? "歌词由 CarPlay 曲目标题同步显示"
                : "暂未找到歌词"
            lastLyricIndex = Int.min
            renderLyrics(force: true)
        }
    }

    func updateLyricsStatus(_ status: String) {
        lyricState = status
        if !lyricData.isTimed && lyricData.plainText.isEmpty { renderLyrics(force: true) }
    }

    private var currentElapsed: Int64 {
        let delta = nowPlaying.playing ? max(0, ProcessInfo.processInfo.systemUptime - elapsedUpdatedAt) : 0
        let elapsed = max(0, nowPlaying.elapsedMillis ?? 0) + Int64(delta * 1000)
        if let duration = nowPlaying.durationMillis, duration > 0 { return min(duration, elapsed) }
        return elapsed
    }

    func refreshProgress() {
        let elapsed = currentElapsed
        let duration = nowPlaying.durationMillis ?? 0
        progress.fraction = duration > 0 ? Double(elapsed) / Double(duration) : 0
        elapsedLabel.stringValue = formatTime(elapsed)
        remainingLabel.stringValue = duration > 0 ? "−" + formatTime(max(0, duration - elapsed)) : "−:−−"
        progress.setAccessibilityValue(duration > 0 ? "\(Int(progress.fraction * 100))%" : "未知时长")
        if lyricsExpanded { renderLyrics() }
    }

    private func renderLyrics(force: Bool = false) {
        guard lyricData.isTimed else {
            lyricLabels.forEach { $0.isHidden = true }
            plainScroll.isHidden = false
            let text = lyricData.plainText.isEmpty ? lyricState : lyricData.plainText
            if plainLyrics.string != text { plainLyrics.string = text; plainLyrics.scrollToBeginningOfDocument(nil) }
            return
        }
        plainScroll.isHidden = true
        let displayLines = lyricData.displayLines
        let active = lyricData.displayIndex(at: Double(currentElapsed) / 1000) ?? -1
        guard force || active != lastLyricIndex else { return }
        lastLyricIndex = active
        let texts: [String]
        if active < 0 { texts = ["", "前奏", displayLines.first?.text ?? ""] }
        else { texts = [active - 1, active, active + 1].map { displayLines.indices.contains($0) ? displayLines[$0].text : "" } }
        for (label, text) in zip(lyricLabels, texts) { label.isHidden = false; label.stringValue = text }
        if !force && !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion {
            lyricArea.alphaValue = 0.75
            NSAnimationContext.runAnimationGroup { context in
                context.duration = 0.18
                lyricArea.animator().alphaValue = 1
            }
        }
    }

    @objc private func previousTrack() { onSourceCommand?("previoustrack") }
    @objc private func nextTrack() { onSourceCommand?("nexttrack") }
    @objc private func togglePlayback() { onSourceCommand?(nowPlaying.playing ? "pause" : "play") }
    @objc private func quit() { onQuit?() }
    @objc private func copyDiagnostics() { onCopyDiagnostics?() }
    @objc private func openUniversalPlayer() { onOpenUniversalPlayer?() }
    @objc func toggleLyrics() {
        lyricsExpanded.toggle()
        lyricArea.isHidden = !lyricsExpanded
        lyricsButton.contentTintColor = lyricsExpanded ? .labelColor : .secondaryLabelColor
        lyricsButton.attributedTitle = NSAttributedString(string: " 歌词", attributes: [.foregroundColor: lyricsExpanded ? NSColor.labelColor : NSColor.secondaryLabelColor, .font: NSFont.systemFont(ofSize: 11.5)])
        lyricsButton.setAccessibilityLabel(lyricsExpanded ? "收起歌词" : "显示歌词")
        lyricsButton.toolTip = lyricsExpanded ? "收起歌词" : "显示歌词"
        placeFooter()
        renderLyrics(force: true)
        onLyricsVisibilityChanged?(lyricsExpanded)
    }

    @objc private func showMenu(_ sender: NSButton) {
        let menu = NSMenu()
        menu.addItem(NSMenuItem(title: "打开音乐中心", action: #selector(openUniversalPlayer), keyEquivalent: "o"))
        menu.addItem(NSMenuItem(title: "复制诊断信息", action: #selector(copyDiagnostics), keyEquivalent: ""))
        menu.addItem(.separator())
        menu.addItem(NSMenuItem(title: "退出 Vela", action: #selector(quit), keyEquivalent: "q"))
        for item in menu.items { item.target = self }
        menu.popUp(positioning: nil, at: NSPoint(x: 0, y: sender.bounds.height), in: sender)
    }

    private func label(_ label: NSTextField, frame: NSRect, size: CGFloat, weight: NSFont.Weight = .regular, secondary: Bool = false) {
        label.frame = frame
        label.font = .systemFont(ofSize: size, weight: weight)
        label.textColor = secondary ? .secondaryLabelColor : .labelColor
        label.lineBreakMode = .byTruncatingTail
        label.maximumNumberOfLines = 1
        content.addSubview(label)
    }
    private func control(_ button: NSButton, symbol: String, label: String, frame: NSRect, action: Selector, size: CGFloat) {
        button.frame = frame
        button.image = NSImage(systemSymbolName: symbol, accessibilityDescription: nil)
        button.symbolConfiguration = .init(pointSize: size, weight: .semibold)
        button.imagePosition = .imageOnly
        button.isBordered = false
        button.contentTintColor = .labelColor
        button.target = self
        button.action = action
        button.toolTip = label
        button.setAccessibilityLabel(label)
        content.addSubview(button)
    }
    private func formatTime(_ ms: Int64) -> String {
        let seconds = max(0, ms / 1000)
        return String(format: "%lld:%02lld", seconds / 60, seconds % 60)
    }
}
