import Darwin
import Foundation

/// Subscribes to MacPlay's same-user CarPlay metadata broadcast. The helper
/// fans this stream out to multiple local clients, so observing it does not
/// take ownership of the CarPlay session.
@MainActor
final class CarPlayNowPlayingFeed {
    private let path = "/tmp/cp-bt.sock"
    private var source: DispatchSourceRead?
    private var retry: Timer?
    private var pending = Data()
    private var stopped = false
    var onEvent: (([String: Any]) -> Void)?

    func start() {
        guard !stopped, source == nil else { return }
        let fd = Darwin.socket(AF_UNIX, SOCK_STREAM, 0)
        guard fd >= 0 else { scheduleRetry(); return }

        _ = fcntl(fd, F_SETFD, FD_CLOEXEC)
        var address = sockaddr_un()
        address.sun_family = sa_family_t(AF_UNIX)
        let bytes = Array(path.utf8) + [0]
        guard bytes.count <= MemoryLayout.size(ofValue: address.sun_path) else {
            Darwin.close(fd)
            scheduleRetry()
            return
        }
        withUnsafeMutableBytes(of: &address.sun_path) { $0.copyBytes(from: bytes) }
        address.sun_len = UInt8(MemoryLayout<sockaddr_un>.size)
        let result = withUnsafePointer(to: &address) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                Darwin.connect(fd, $0, socklen_t(MemoryLayout<sockaddr_un>.size))
            }
        }
        guard result == 0 else {
            Darwin.close(fd)
            scheduleRetry()
            return
        }

        var noSignal: Int32 = 1
        setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &noSignal, socklen_t(MemoryLayout<Int32>.size))
        let request = Array("subscribe\n".utf8)
        let sent = request.withUnsafeBytes { Darwin.write(fd, $0.baseAddress, request.count) }
        guard sent == request.count, fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK) == 0 else {
            Darwin.close(fd)
            scheduleRetry()
            return
        }

        pending.removeAll(keepingCapacity: true)
        let reader = DispatchSource.makeReadSource(fileDescriptor: fd, queue: .main)
        reader.setEventHandler { [weak self] in
            MainActor.assumeIsolated { self?.readEvents(fd) }
        }
        reader.setCancelHandler { Darwin.close(fd) }
        source = reader
        reader.resume()
    }

    private func readEvents(_ fd: Int32) {
        var bytes = [UInt8](repeating: 0, count: 65_536)
        for _ in 0..<16 {
            let count = Darwin.read(fd, &bytes, bytes.count)
            if count < 0 && errno == EINTR { continue }
            if count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK) { return }
            guard count > 0 else {
                source?.cancel()
                source = nil
                scheduleRetry()
                return
            }
            pending.append(contentsOf: bytes.prefix(count))
            while let end = pending.firstIndex(of: 0x0a) {
                let line = pending[..<end]
                pending.removeSubrange(...end)
                guard let object = try? JSONSerialization.jsonObject(with: line),
                      let event = object as? [String: Any],
                      let type = event["type"] as? String,
                      ["nowplaying", "albumart", "seekResult"].contains(type) else { continue }
                onEvent?(event)
            }
            if pending.count > 12 * 1024 * 1024 { pending.removeAll(keepingCapacity: true) }
        }
    }

    private func scheduleRetry() {
        guard !stopped, retry == nil else { return }
        retry = Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { [weak self] _ in
            MainActor.assumeIsolated {
                self?.retry = nil
                self?.start()
            }
        }
    }

    func stop() {
        stopped = true
        retry?.invalidate()
        retry = nil
        source?.cancel()
        source = nil
    }
}
