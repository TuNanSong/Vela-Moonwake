import AppKit
import SwiftUI
import WebKit

private enum VelaTheme { static let accent = Color(red: 0.88, green: 0.27, blue: 0.22) }

@MainActor
final class PlayerHubModel: ObservableObject {
    enum Section: String, Identifiable {
        case player = "正在播放"
        case carPlay = "iPhone CarPlay"
        case library = "音乐库"
        case settings = "设置"
        var id: String { rawValue }
    }

    @Published var section: Section = .player
    @Published var title = "等待播放"
    @Published var artist = "连接 iPhone 或打开音乐库开始播放"
    @Published var album = ""
    @Published var status = "等待 iPhone CarPlay 或音乐库播放"
    @Published var playing = false
    @Published var elapsed: Double = 0
    @Published var duration: Double = 0
    @Published var artwork: NSImage?
    @Published var localSiteURL: URL?
    @Published var websiteReady = false
    @Published var source = "音乐库"
    @Published var macPlayInstalled = CarPlayBackend.isBundled
    @Published var macPlayRunning = NSRunningApplication.runningApplications(withBundleIdentifier: "com.roylyl.macplay").contains { !$0.isTerminated }
    @Published var macPlayLaunchError: String?
    private var webPlaybackActive = false
    private var carPlayState = CarPlayPlaybackState()
    var carPlayMetadataTrackID: String? { carPlayState.trackID }
    private var matchedLyrics = ""
    private var matchedLyricsKey = ""
    private var matchedArtworkByAlbum: [String: NSImage] = [:]
    private var currentArtworkURL = ""
    let carPlayVideo = CarPlayVideo()
    let projection = CarPlayProjection()
    @Published var projectionDisplayID: UInt32 = UInt32(clamping:UserDefaults.standard.integer(forKey:"Vela.projectionDisplayID")) { didSet { UserDefaults.standard.set(Int(projectionDisplayID),forKey:"Vela.projectionDisplayID") } }
    @Published var backgroundEnabled = UserDefaults.standard.object(forKey:"Vela.backgroundEnabled") as? Bool ?? true { didSet {UserDefaults.standard.set(backgroundEnabled,forKey:"Vela.backgroundEnabled")} }
    @Published var carPlayVolume = 1.0
    @Published var carPlayCallVolume = 1.0
    @Published var carPlayAudioEnabled = true
    var carPlayAudioEditing = false
    var onCarPlayAudio: ((Double,Double,Bool) -> Void)?
    @Published var carPlayUSBCount = 0
    @Published var carPlayDetail = ""
    @Published var carPlayEmbedded = false
    @Published var carPlayConnected = false
    @Published var carPlayConnecting = false
    @Published var carPlayControlReady = false
    @Published var carPlayCanSeek = false
    @Published var carPlayPhones: [PhoneOption] = []
    @Published var carPlaySelectedPhone = ""
    @Published var carPlayWireless = false
    var carPlayConfigurationEdited = false
    struct PhoneOption: Identifiable { let id: String; let name: String }
    @Published var carPlaySettingsPresented = false
    @Published var carPlayConfiguration: CarPlayConfiguration?
    @Published var carPlayEngineRunning = false
    @Published var carPlayBackendStarting = false
    var onOpenCarPlaySettings: ((Bool) -> Void)?
    var onSaveCarPlaySettings: ((CarPlayConfiguration,String,Bool,@escaping (String?) -> Void) -> Void)?
    @Published var carPlayStatus = "等待 iPhone 连接"
    @Published var playbackError: String?
    @Published var lyrics = ""
    @Published var lyricsMatching = false
    @Published var lyricsMatchFailed = false
    @Published var queue: [QueueTrack] = []
    @Published var queueIndex = 0
    @Published var lyricLines: [String] = []
    private(set) var miniLyrics = ""
    struct QueueTrack: Identifiable { let id: Int; let title: String; let artist: String; let artworkURL: URL? }
    private var lastTrackKey = ""
    private var preferredSource = ""
    private var lastWebMetadata: [String: Any]?

    var onWebAction: ((String, Double?) -> Void)?
    var onCarPlayAction: ((String, Double?) -> Void)?
    var onCarPlayConnect: ((String, Bool) -> Void)?
    var onWebMetadata: ((NowPlaying, String) -> Void)?
    var onArtworkChanged: ((NSImage?) -> Void)?
    var onMiniPlayerChanged: (() -> Void)?

    var carPlayStatusCaption: String {
        if carPlayConnected { return "iPhone 已连接" }
        if carPlayControlReady { return "CarPlay 已就绪" }
        if carPlayBackendStarting { return "正在启动 CarPlay" }
        if macPlayRunning { return "等待 iPhone 连接" }
        return "CarPlay 接收端未启动"
    }

    var carPlayConnectionMessage: String {
        if carPlayConnected { return "iPhone 已连接，CarPlay 画面与播放状态已同步" }
        if carPlayConnecting { return "正在连接 iPhone…" }
        if carPlayBackendStarting { return "正在启动 CarPlay 接收端…" }
        if carPlayControlReady {
            return carPlayWireless
                ? "接收端已就绪 · 等待 iPhone 建立无线连接"
                : carPlayUSBCount > 0
                    ? "接收端已就绪 · 已检测到 USB iPhone"
                    : "接收端已就绪 · 连接 iPhone 后即可使用 CarPlay"
        }
        if !carPlayDetail.isEmpty { return carPlayDetail }
        return carPlayStatus
    }

    func selectSource(_ value: String) {
        if !value.isEmpty, value != source, playing { perform("pause") }
        if value != source { lyricsMatching = false; lyricsMatchFailed = false }
        preferredSource = value
        guard !value.isEmpty else { return }
        source = value
        switch value {
        case "iPhone CarPlay": publishCarPlayState()
        case "音乐库": if let payload = lastWebMetadata { receiveWebMetadata(payload) }
        default: break
        }
        onMiniPlayerChanged?()
    }
    var hasLibraryTrack: Bool { lastWebMetadata != nil }
    var canControl: Bool { source == "音乐库" ? onWebAction != nil : carPlayConnected && carPlayControlReady }
    func perform(_ action: String, value: Double? = nil) {
        playbackError = nil
        if source == "音乐库" { onWebAction?(action, value) }
        else if source == "iPhone CarPlay" { onCarPlayAction?(action, value) }
        else { onCarPlayAction?(action, value) }
    }

    func receiveCarPlay(_ event: [String: Any]) {
        carPlayState.receive(event, at: ProcessInfo.processInfo.systemUptime)
        // Connection belongs to the owned service status, not a shared metadata event.
        guard preferredSource.isEmpty || preferredSource == "iPhone CarPlay" else { return }
        guard !webPlaybackActive || preferredSource == "iPhone CarPlay" else { return }
        publishCarPlayState()
    }
    private func publishCarPlayState() {
        guard !carPlayState.title.isEmpty else { return }
        let nextKey = [carPlayState.title, carPlayState.artist, carPlayState.album].joined(separator: "\u{1f}")
        if nextKey != lastTrackKey {
            lyrics = ""; lyricLines = []; miniLyrics = ""
            matchedLyrics = ""; matchedLyricsKey = ""
            lyricsMatching = false; lyricsMatchFailed = false
        }
        source = "iPhone CarPlay"
        currentArtworkURL = ""
        title = carPlayState.title; artist = carPlayState.artist; album = carPlayState.album
        duration = carPlayState.duration; elapsed = carPlayState.position
        playing = carPlayState.rate > 0; carPlayCanSeek = carPlayState.canSeek
        let liveArtwork = carPlayState.artwork.flatMap(NSImage.init(data:))
        let albumKey = Self.albumArtworkKey(artist: carPlayState.artist, album: carPlayState.album)
        artwork = liveArtwork ?? matchedArtworkByAlbum[albumKey]
        lastTrackKey = nextKey
        queue = []
        refreshMatchedLyrics()
        onArtworkChanged?(artwork)
        onMiniPlayerChanged?()
    }

    func applyMatchedArtwork(_ image: NSImage, artist: String, album: String) {
        let key = Self.albumArtworkKey(artist: artist, album: album)
        guard !album.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        matchedArtworkByAlbum[key] = image
        if matchedArtworkByAlbum.count > 32, let stale = matchedArtworkByAlbum.keys.first(where: { $0 != key }) {
            matchedArtworkByAlbum.removeValue(forKey: stale)
        }
        guard source == "iPhone CarPlay",
              self.artist.trimmingCharacters(in: .whitespacesAndNewlines) == artist,
              self.album.trimmingCharacters(in: .whitespacesAndNewlines) == album,
              carPlayState.artwork == nil else { return }
        artwork = image
        onArtworkChanged?(image)
        onMiniPlayerChanged?()
    }

    private static func albumArtworkKey(artist: String, album: String) -> String {
        [artist, album].map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
            .joined(separator: "\u{1f}")
    }

    func refreshPlaybackClock() {
        guard source == "iPhone CarPlay", carPlayConnected else { return }
        carPlayState.advance(to: ProcessInfo.processInfo.systemUptime)
        elapsed = carPlayState.position
        refreshMatchedLyrics()
        onMiniPlayerChanged?()
    }

    func openMacPlay(activate: Bool = true) { onOpenCarPlaySettings?(activate) }

    func updateStatus(_ value: String) {
        status = value
        onMiniPlayerChanged?()
    }

    func receiveWebMetadata(_ payload: [String: Any]) {
        guard let title = payload["title"] as? String, !title.isEmpty else {
            webPlaybackActive = false
            return
        }
        lastWebMetadata = payload
        let incomingPlaying = (payload["playing"] as? String) == "playing"
        webPlaybackActive = incomingPlaying
        guard preferredSource.isEmpty || preferredSource == "音乐库" else { return }
        if !incomingPlaying, source == "iPhone CarPlay", carPlayConnected, preferredSource.isEmpty { return }
        webPlaybackActive = incomingPlaying
        source = "音乐库"
        self.title = title
        artist = payload["artist"] as? String ?? "音乐下载"
        album = payload["album"] as? String ?? ""
        lastTrackKey = [title, artist, album].joined(separator: "\u{1f}")
        playing = (payload["playing"] as? String) == "playing"
        if let duration = payload["duration"] as? Double { self.duration = duration }
        if let elapsed = payload["elapsed"] as? Double { self.elapsed = elapsed }
        lyrics = payload["lyrics"] as? String ?? ""
        lyricLines = payload["lyricLines"] as? [String] ?? []
        miniLyrics = lyrics.isEmpty ? lyricLines.joined(separator: "\n") : lyrics
        queueIndex = payload["queueIndex"] as? Int ?? 0
        if let tracks = payload["queue"] as? [[String: Any]] {
            queue = tracks.enumerated().map { QueueTrack(id: $0.offset, title: $0.element["title"] as? String ?? "", artist: $0.element["artist"] as? String ?? "", artworkURL: ($0.element["cover"] as? String).flatMap(URL.init(string:))) }
        }
        let track = NowPlaying(title: title, artist: artist, album: album,
                               durationMillis: Int64(self.duration * 1000), elapsedMillis: Int64(self.elapsed * 1000),
                               playing: self.playing)
        onWebMetadata?(track, lyricLines.joined(separator: "\n"))
        let raw = payload["artwork"] as? String ?? ""
        guard raw != currentArtworkURL else { onMiniPlayerChanged?(); return }
        currentArtworkURL = raw
        artwork = nil
        guard let url = URL(string: raw), url.scheme == "http" || url.scheme == "https" else { onArtworkChanged?(nil); onMiniPlayerChanged?(); return }
        URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let data, let image = NSImage(data: data) else { return }
            Task { @MainActor in
                guard self?.currentArtworkURL == raw, self?.source == "音乐库" else { return }
                self?.artwork = image
                self?.onArtworkChanged?(image)
                self?.onMiniPlayerChanged?()
            }
        }.resume()
        onMiniPlayerChanged?()
    }

    func applyMatchedLyrics(_ raw: String, for track: NowPlaying) {
        matchedLyricsKey = [track.title ?? "", track.artist ?? "", track.album ?? ""].joined(separator: "\u{1f}")
        matchedLyrics = raw
        guard matchedLyricsKey == lastTrackKey else { return }
        lyricsMatching = false
        lyricsMatchFailed = false
        refreshMatchedLyrics()
        miniLyrics = raw
        onMiniPlayerChanged?()
    }

    func setLyricsMatching(_ matching: Bool, failed: Bool = false) {
        lyricsMatching = matching
        lyricsMatchFailed = failed
        onMiniPlayerChanged?()
    }

    private func refreshMatchedLyrics() {
        guard source != "音乐库", !matchedLyrics.isEmpty, matchedLyricsKey == lastTrackKey else { return }
        let parsed = Lyrics(matchedLyrics)
        lyricLines = parsed.isTimed ? parsed.displayLines.map(\.text) : matchedLyrics.components(separatedBy: .newlines).filter { !$0.isEmpty }
        lyrics = parsed.displayIndex(at: elapsed).map { parsed.displayLines[$0].text } ?? ""
    }
}

final class UniversalPlayerWindowController: NSWindowController, NSWindowDelegate {
    let model = PlayerHubModel()

    init() {
        let root = PlayerHubView(model: model)
        let host = NSHostingController(rootView: root)
        let window = NSWindow(contentViewController: host)
        window.title = "Vela · 音乐中心"
        window.titlebarAppearsTransparent = false
        window.setContentSize(NSSize(width: 1120, height: 720))
        window.minSize = NSSize(width: 1000, height: 620)
        window.center()
        window.isReleasedWhenClosed = false
        super.init(window: window)
        window.delegate=self
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    func windowShouldClose(_ sender:NSWindow) -> Bool {
        if !model.backgroundEnabled {NSApp.terminate(nil);return false}
        return true
    }

    func show() {
        showWindow(nil)
        window?.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }
}

private struct PlayerHubView: View {
    @ObservedObject var model: PlayerHubModel
    @State private var playbackDetail = 0
    @State private var pointerOverCarPlayVideo = false
    private var websiteRoute: String {
        model.localSiteURL?.absoluteString ?? ""
    }

    var body: some View {
        HStack(spacing: 0) {
            sidebar
            Rectangle().fill(Color(nsColor: .separatorColor).opacity(0.35)).frame(width: 1)
            VStack(spacing: 0) {
                if model.section != .player { topBar }
                ZStack {
                    MusicDownloaderWebView(model: model, urlString: websiteRoute)
                        .opacity(model.section == .library ? 1 : 0)
                        .allowsHitTesting(model.section == .library)
                        .accessibilityHidden(model.section != .library)
                    if model.section == .player {
                        HStack(spacing: 0) {
                            ZStack(alignment: .topTrailing) {
                                nowPlaying
                                if model.title != "等待播放" {
                                    sourcePicker
                                        .padding(.top, 18)
                                        .padding(.trailing, 22)
                                }
                            }
                            if playbackDetail > 0 { Divider(); playbackDetails.frame(width: 250) }
                        }.background(Color(nsColor: .windowBackgroundColor))
                    }
                    if model.section == .carPlay { carPlayReceiver.background(Color(nsColor: .windowBackgroundColor)).onAppear { if !model.carPlayControlReady { model.openMacPlay(activate:false) } } }
                    if model.section == .settings { settingsView.background(Color(nsColor: .windowBackgroundColor)) }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .background(Color(nsColor: .windowBackgroundColor))
        .preferredColorScheme(nil)
        .sheet(isPresented:$model.carPlaySettingsPresented) {
            if let configuration=model.carPlayConfiguration {
                CarPlaySettings(configuration:configuration) { draft,password,clear,completion in
                    model.onSaveCarPlaySettings?(draft,password,clear,completion)
                }
            }
        }
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 10) {
                Image(systemName: "waveform")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(VelaTheme.accent)
                Text("Vela").font(.system(size: 15, weight: .semibold))
            }
            .padding(.horizontal, 14)
            .padding(.top, 19)
            .padding(.bottom, 27)

            sectionButton(.player)

            Text("来源")
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(.tertiary)
                .padding(.horizontal, 17)
                .padding(.top, 20)
                .padding(.bottom, 3)
            sectionButton(.carPlay)
            sectionButton(.library)

            if model.section == .player && model.title != "等待播放" {
                Divider().padding(.horizontal, 14).padding(.top, 17).padding(.bottom, 11)
                Text("播放内容")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.tertiary)
                    .padding(.horizontal, 17)
                    .padding(.bottom, 5)
                playbackDetailButton(2, title: "歌词", symbol: "text.quote")
                playbackDetailButton(1, title: "播放队列", symbol: "list.bullet")
            }

            Spacer()

            HStack(spacing: 7) {
                Circle().fill(model.carPlayConnected ? Color.green : Color.secondary.opacity(0.62)).frame(width: 7, height: 7)
                Text(model.carPlayStatusCaption)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .truncationMode(.tail)
                Spacer(minLength: 0)
                Button { model.section = .settings } label: {
                    Image(systemName: "gearshape")
                        .font(.system(size: 14, weight: .regular))
                        .frame(width: 30, height: 30)
                        .contentShape(RoundedRectangle(cornerRadius: 8))
                }
                .buttonStyle(.plain)
                .foregroundStyle(model.section == .settings ? VelaTheme.accent : Color.secondary)
                .help("设置")
                .accessibilityLabel("设置")
            }
            .padding(.horizontal, 13)
            .padding(.bottom, 14)
        }
        .frame(width: 198)
        .background(Color(nsColor: .controlBackgroundColor).opacity(0.72))
    }

    private func sectionButton(_ section: PlayerHubModel.Section) -> some View {
        Button { model.section = section } label: {
            Label(section.rawValue, systemImage: symbol(for: section))
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .contentShape(RoundedRectangle(cornerRadius: 9))
        }
        .buttonStyle(.plain)
        .foregroundStyle(model.section == section ? VelaTheme.accent : Color.primary.opacity(0.78))
        .background(model.section == section ? VelaTheme.accent.opacity(0.10) : .clear, in: RoundedRectangle(cornerRadius: 9))
        .padding(.horizontal, 9)
    }

    private func playbackDetailButton(_ detail: Int, title: String, symbol: String) -> some View {
        Button { playbackDetail = playbackDetail == detail ? 0 : detail } label: {
            Label(title, systemImage: symbol)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .contentShape(RoundedRectangle(cornerRadius: 8))
        }
        .buttonStyle(.plain)
        .foregroundStyle(playbackDetail == detail ? VelaTheme.accent : Color.primary.opacity(0.78))
        .background(playbackDetail == detail ? VelaTheme.accent.opacity(0.11) : .clear, in: RoundedRectangle(cornerRadius: 8))
        .padding(.horizontal, 9)
    }

    private var topBar: some View {
        HStack {
            Text(model.section.rawValue).font(.system(size: 19, weight: .semibold))
            Spacer()
            if model.section == .library {
                Button {
                    if let url = model.localSiteURL { NSWorkspace.shared.open(url) }
                } label: {
                    Label("在浏览器中打开", systemImage: "arrow.up.right.square")
                }
                .buttonStyle(.bordered)
                .disabled(model.localSiteURL == nil)
            } else if model.section == .carPlay {
                Menu {
                    Button("独立投屏窗口") { model.projection.show(displayID:model.projectionDisplayID,fullscreen:false,video:model.carPlayVideo) }
                    Button("全屏投屏") { model.projection.show(displayID:model.projectionDisplayID,fullscreen:true,video:model.carPlayVideo) }
                    Divider()
                    Picker("显示位置",selection:$model.projectionDisplayID) {
                        Text("当前主屏幕").tag(UInt32(0))
                        ForEach(Array(NSScreen.screens.enumerated()),id:\.offset) { _, screen in Text(screen.localizedName).tag(CarPlayProjection.displayID(screen)) }
                    }
                } label: { Label("投屏显示",systemImage:"display") }
                .fixedSize()
                .disabled(!model.carPlayControlReady)
            }
        }
        .padding(.horizontal, 24)
        .frame(height: 62)
        .background(.regularMaterial)
        .overlay(alignment: .bottom) { Rectangle().fill(Color(nsColor: .separatorColor).opacity(0.35)).frame(height: 1) }
    }

    private var sourcePicker: some View {
        Menu {
            Button("自动跟随播放来源") { model.selectSource("") }
            Divider()
            Button("iPhone CarPlay") { model.selectSource("iPhone CarPlay") }.disabled(!model.carPlayConnected)
            Button("音乐库") { model.selectSource("音乐库") }.disabled(!model.hasLibraryTrack)
        } label: {
            Label(model.source, systemImage: "hifispeaker")
                .font(.system(size: 12, weight: .medium))
                .padding(.horizontal, 11)
                .padding(.vertical, 7)
                .background(Color(nsColor: .controlBackgroundColor).opacity(0.82), in: Capsule())
        }
        .menuStyle(.borderlessButton)
        .fixedSize()
        .help("切换播放来源")
    }

    private var nowPlaying: some View {
        Group {
            if model.title == "等待播放" {
                receiverOverview
            } else {
                activeNowPlaying
            }
        }
    }

    private var receiverOverview: some View {
        let subtitle = model.carPlayConnected
            ? "iPhone 已连接，CarPlay 歌曲会显示在这里。"
            : "连接 iPhone 使用 CarPlay，或在音乐库中选一首歌。"
        return VStack(spacing: 0) {
            Spacer(minLength: 24)
            Text("开始听音乐")
                .font(.system(size: 27, weight: .semibold))
                .tracking(-0.3)
                .padding(.bottom, 10)
            Text(subtitle)
                .font(.system(size: 14))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .lineSpacing(3)
                .frame(maxWidth: 390)
                .padding(.bottom, 20)
            HStack(spacing: 10) {
                Button {
                    model.section = .carPlay
                    if !model.macPlayRunning { model.openMacPlay(activate: false) }
                } label: {
                    Label(model.carPlayConnected ? "查看 CarPlay" : "连接 iPhone", systemImage: "iphone.gen3.radiowaves.left.and.right")
                }
                .buttonStyle(.borderedProminent)
                .tint(VelaTheme.accent)
                .controlSize(.large)
                Button("打开音乐库") { model.section = .library }
                    .buttonStyle(.bordered)
                    .controlSize(.large)
            }
            .padding(.bottom, 10)
            Spacer(minLength: 24)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(36)
        .background(Color(nsColor: .windowBackgroundColor))
    }

    private var activeNowPlaying: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 34)
            HStack(spacing: 32) {
                Group {
                    if let image = model.artwork {
                        Image(nsImage: image).resizable().scaledToFill()
                    } else {
                        ZStack {
                            RoundedRectangle(cornerRadius: 16).fill(VelaTheme.accent.opacity(0.1))
                            Image(systemName: "music.note").font(.system(size: 34, weight: .light)).foregroundStyle(VelaTheme.accent.opacity(0.72))
                        }
                    }
                }
                .frame(width: 224, height: 224)
                .clipShape(RoundedRectangle(cornerRadius: 20))
                VStack(alignment: .leading, spacing: 9) {
                    Text(model.title).font(.system(size: 29, weight: .semibold)).lineLimit(2)
                    Text(model.artist).font(.system(size: 16)).foregroundStyle(.secondary).lineLimit(1)
                    if !model.album.isEmpty { Text(model.album).font(.system(size: 13)).foregroundStyle(.tertiary).lineLimit(1) }
                }
                Spacer(minLength: 8)
            }
            .padding(.horizontal, 48)
            .frame(maxWidth: 800)
            .frame(height: 244)

            HStack(spacing: 13) {
                Text(time(model.elapsed))
                    .font(.system(size: 11, design: .rounded).monospacedDigit())
                    .foregroundStyle(.secondary)
                Slider(value: Binding(get: { min(model.elapsed, max(1, model.duration)) }, set: { model.elapsed = $0 }), in: 0...max(1, model.duration), onEditingChanged: { editing in if !editing { model.perform("seekto", value: model.elapsed) } })
                    .tint(VelaTheme.accent)
                    .disabled(model.duration <= 0 || (model.source == "iPhone CarPlay" && !model.carPlayCanSeek))
                    .accessibilityLabel("播放进度")
                Text(model.duration > 0 ? "−" + time(max(0, model.duration - model.elapsed)) : "−:−−")
                    .font(.system(size: 11, design: .rounded).monospacedDigit())
                    .foregroundStyle(.secondary)
                    .frame(width: 42, alignment: .trailing)
            }
            .frame(maxWidth: 710)
            .padding(.top, 37)

            HStack(spacing: 27) {
                transport("backward.end.fill", label: "上一曲") { model.perform("previoustrack") }
                Button { model.perform(model.playing ? "pause" : "play") } label: {
                    Image(systemName: model.playing ? "pause.fill" : "play.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .contentTransition(.symbolEffect(.replace))
                        .frame(width: 60, height: 60)
                }
                .buttonStyle(.plain)
                .foregroundStyle(.white)
                .background(VelaTheme.accent, in: Circle())
                .opacity(model.canControl ? 1 : 0.45)
                .disabled(!model.canControl)
                .help(model.playing ? "暂停" : "播放")
                transport("forward.end.fill", label: "下一曲") { model.perform("nexttrack") }
            }
            .padding(.top, 19)

            Spacer(minLength: 34)
            if let error = model.playbackError {
                Text(error).font(.system(size: 12)).foregroundStyle(.red).padding(.bottom, 12)
            }
        }
        .padding(.horizontal, 26)
        .padding(.bottom, 10)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var playbackDetails: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Text(playbackDetail == 1 ? "播放队列" : "歌词").font(.system(size: 16, weight: .semibold))
                Spacer()
                Button { playbackDetail = 0 } label: { Image(systemName: "xmark") }.buttonStyle(.plain).help("关闭")
            }
            if playbackDetail == 1 {
                if model.queue.isEmpty {
                    Text(model.source == "iPhone CarPlay" ? "播放队列由 iPhone 上的音乐应用管理。" : "在音乐库中播放歌曲，即可查看队列。")
                        .font(.system(size: 13)).foregroundStyle(.secondary)
                }
                ScrollView {
                    LazyVStack(spacing: 4) {
                        ForEach(model.queue) { track in
                            Button { model.perform("queueitem", value: Double(track.id)) } label: {
                                HStack(spacing: 10) {
                                    AsyncImage(url: track.artworkURL) { image in image.resizable().scaledToFill() } placeholder: { Image(systemName: "music.note").foregroundStyle(.secondary) }
                                        .frame(width: 34, height: 34).clipShape(RoundedRectangle(cornerRadius: 6))
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(track.title).font(.system(size: 13, weight: .medium)).lineLimit(1)
                                        Text(track.artist).font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    Spacer(minLength: 0)
                                    if track.id == model.queueIndex { Image(systemName: "speaker.wave.2.fill").font(.system(size: 11)).foregroundStyle(VelaTheme.accent) }
                                }.padding(8).contentShape(Rectangle())
                            }.buttonStyle(.plain)
                                .background(track.id == model.queueIndex ? VelaTheme.accent.opacity(0.08) : .clear, in: RoundedRectangle(cornerRadius: 8))
                        }
                    }
                }
            } else {
                if model.lyricLines.isEmpty {
                    Text(model.lyricsMatching ? "正在匹配歌词…" : model.source == "iPhone CarPlay"
                         ? (model.lyricsMatchFailed ? "暂未匹配到歌词。可以在手机音乐应用或投屏中查看。" : "CarPlay 未提供独立歌词，歌曲标题会按手机实际内容显示。")
                         : "这首歌暂未提供歌词。")
                        .font(.system(size: 13)).foregroundStyle(.secondary)
                } else {
                    ScrollViewReader { proxy in
                        ScrollView {
                            VStack(alignment: .leading, spacing: 20) {
                                ForEach(Array(model.lyricLines.enumerated()), id: \.offset) { index, line in
                                    Text(line).font(.system(size: 16, weight: line == model.lyrics ? .semibold : .regular))
                                        .foregroundStyle(line == model.lyrics ? Color.primary : Color.secondary).id(index)
                                }
                            }.frame(maxWidth: .infinity, alignment: .leading)
                        }.onChange(of: model.lyrics) { _, line in
                            if let index = model.lyricLines.firstIndex(of: line) { proxy.scrollTo(index, anchor: .center) }
                        }
                    }
                }
            }
            Spacer(minLength: 0)
        }.padding(20).frame(maxHeight: .infinity).background(Color(nsColor: .controlBackgroundColor))
    }

    private func transport(_ symbol: String, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .semibold))
                .frame(width: 44, height: 44)
                .background(Color.primary.opacity(0.055), in: Circle())
        }
        .buttonStyle(.plain)
        .foregroundStyle(model.canControl ? Color.primary : Color.secondary.opacity(0.4))
        .disabled(!model.canControl)
        .help(label)
    }

    private func symbol(for section: PlayerHubModel.Section) -> String {
        switch section {
        case .player: return "waveform"
        case .carPlay: return "iphone.gen3.radiowaves.left.and.right"
        case .library: return "music.note.list"
        case .settings: return "slider.horizontal.3"
        }
    }

    private var carPlayReceiver: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                if model.carPlayControlReady {
                    HStack(spacing: 10) {
                        Picker("设备", selection: Binding(get: { model.carPlaySelectedPhone }, set: { model.carPlaySelectedPhone = $0; model.carPlayConfigurationEdited = true })) {
                            Text("自动选择").tag("")
                            ForEach(model.carPlayPhones) { phone in Text(phone.name).tag(phone.id) }
                        }.labelsHidden().frame(maxWidth: 260)
                        Picker("连接方式", selection: Binding(get: { model.carPlayWireless }, set: { model.carPlayWireless = $0; model.carPlayConfigurationEdited = true })) {
                            Text("USB").tag(false)
                            Text("Wi-Fi").tag(true)
                        }.pickerStyle(.segmented).labelsHidden().frame(width: 140)
                        Spacer(minLength: 0)
                        Button(model.carPlayConnecting ? "正在连接…" : "连接 iPhone") { model.onCarPlayConnect?(model.carPlaySelectedPhone, model.carPlayWireless) }
                            .buttonStyle(.borderedProminent).disabled(model.carPlayConnecting)
                        if model.carPlayConnected || model.carPlayConnecting {
                            Button("停止") { model.onCarPlayAction?("stop", nil) }.buttonStyle(.bordered)
                        }
                        Button { model.openMacPlay() } label: { Image(systemName: "gearshape") }
                            .buttonStyle(.bordered).help("CarPlay 连接设置")
                    }
                } else {
                    HStack(spacing: 12) {
                        Label(model.carPlayBackendStarting ? "正在启动 CarPlay 接收端…" : "启动接收端以连接 iPhone", systemImage: "iphone")
                            .font(.system(size: 13)).foregroundStyle(.secondary)
                        Spacer()
                        Button(model.carPlayBackendStarting ? "正在准备…" : "启动接收端") { model.openMacPlay() }
                            .buttonStyle(.borderedProminent).tint(VelaTheme.accent)
                            .disabled(!model.macPlayInstalled || model.carPlayEngineRunning || model.carPlayBackendStarting)
                    }
                }
                HStack(spacing: 8) {
                    Circle().fill(model.carPlayConnected ? Color.green : Color.secondary.opacity(0.55)).frame(width: 7, height: 7)
                    Text(model.carPlayConnectionMessage)
                }
                .font(.system(size: 12)).foregroundStyle(.secondary).lineLimit(1)
                if model.carPlayConnected {
                    HStack(spacing:18) {
                        Toggle("iPhone 音频",isOn:Binding(get:{model.carPlayAudioEnabled},set:{model.carPlayAudioEnabled=$0;model.onCarPlayAudio?(model.carPlayVolume,model.carPlayCallVolume,$0)})).toggleStyle(.switch)
                        liveAudioSlider("音乐",value:$model.carPlayVolume)
                        liveAudioSlider("通话",value:$model.carPlayCallVolume)
                    }.font(.caption)
                }
                CarPlayVideoPanel(video: model.carPlayVideo, connected: model.carPlayConnected, pointerInside: $pointerOverCarPlayVideo)
                if let error = model.playbackError ?? model.macPlayLaunchError {
                    Text(error).font(.system(size: 12)).foregroundStyle(.red)
                }
            }
            .frame(maxWidth: 900, alignment: .leading).padding(24)
        }
        .scrollDisabled(pointerOverCarPlayVideo && model.carPlayVideo.receiving)
        .background(Color(nsColor: .windowBackgroundColor))
    }

    private func liveAudioSlider(_ title:String,value:Binding<Double>) -> some View {
        HStack(spacing:7) {
            Text(title)
            Slider(value:value,in:0...1,onEditingChanged:{model.carPlayAudioEditing=$0})
                .frame(width:120).disabled(!model.carPlayAudioEnabled)
                .onChange(of:value.wrappedValue) { _,_ in model.onCarPlayAudio?(model.carPlayVolume,model.carPlayCallVolume,model.carPlayAudioEnabled) }
            Text("\(Int(value.wrappedValue*100))%").monospacedDigit().frame(width:38,alignment:.trailing)
        }
    }

    private var settingsView: some View {
        Form {
            SwiftUI.Section("手机接收") {
                LabeledContent("iPhone CarPlay", value: model.carPlayConnected ? "已连接" : model.carPlayStatus)
                Button("iPhone 设备与连接") { model.section = .carPlay }
            }
            SwiftUI.Section("运行方式") {
                Toggle("关闭主窗口后继续播放与接收",isOn:$model.backgroundEnabled)
                Text("开启后可通过菜单栏重新打开。退出 Vela 会停止所有接收服务。").font(.caption).foregroundStyle(.secondary)
            }
            SwiftUI.Section("音乐库") {
                Text("音乐搜索、歌单、下载进度和账户登录由已有音乐服务提供。")
                    .font(.system(size: 12)).foregroundStyle(.secondary)
                Button("音乐账户与下载设置…") { model.section = .library; model.onWebAction?("settings", nil) }
                if let url = model.localSiteURL { Link("在浏览器中打开音乐库", destination: url) }
            }
            SwiftUI.Section("关于 Vela") {
                LabeledContent("版本", value: Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "")
                Text("音乐播放器 · iPhone CarPlay").font(.system(size: 12)).foregroundStyle(.secondary)
                Link("MacPlay 源代码 · GPL-3.0-or-later", destination: URL(string: "https://github.com/roylyl/MacPlay")!)
                Link("Go Music DL 源代码 · AGPL-3.0", destination: URL(string: "https://github.com/guohuiyuan/go-music-dl")!)
            }
        }.formStyle(.grouped)
    }

    private func time(_ seconds: Double) -> String {
        let total = max(0, Int(seconds))
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}

private struct MusicDownloaderWebView: NSViewRepresentable {
    @ObservedObject var model: PlayerHubModel
    let urlString: String

    func makeCoordinator() -> Coordinator { Coordinator(model: model) }

    func makeNSView(context: Context) -> WKWebView {
        let content = WKUserContentController()
        content.add(context.coordinator, name: "musicNowPlaying")
        content.addUserScript(WKUserScript(source: Self.bridgeScript, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        let configuration = WKWebViewConfiguration()
        configuration.userContentController = content
        configuration.mediaTypesRequiringUserActionForPlayback = []
        if CommandLine.arguments.contains("--verify-playback") { configuration.websiteDataStore = .nonPersistent() }
        content.addUserScript(WKUserScript(source: Self.nativeStyleScript, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        context.coordinator.webView = webView
        context.coordinator.reload(urlString)
        model.onWebAction = { [weak webView, weak model] action, value in
            guard let webView else { model?.playbackError = "音乐页面未就绪，请打开音乐库"; return }
            let arguments: [Any] = [action, value as Any? ?? NSNull()]
            guard let data = try? JSONSerialization.data(withJSONObject: arguments), let json = String(data: data, encoding: .utf8) else { return }
            webView.evaluateJavaScript("window.__diplayPlayerAction(...\(json))") { _, error in
                if error != nil { Task { @MainActor in model?.playbackError = "播放控制未发送，请打开音乐库重试" } }
            }
        }
        return webView
    }

    func updateNSView(_ webView: WKWebView, context: Context) {
        context.coordinator.model = model
        context.coordinator.reload(urlString)

    }

    private static let nativeStyleScript = #"""
(() => {
 const style = document.createElement('style');
 style.textContent = `
 :root{--primary-color:#DF4538;--primary-gradient:#DF4538;--text-main:#252527;--text-sub:#68686d;--shadow:none;--shadow-active:none}
 body{background:#fafafa!important;background-image:none!important;padding:26px 58px 120px 26px!important;min-height:100%;box-sizing:border-box;font-size:13px}
 .container{max-width:100%;width:100%}.search-box{padding:0!important;border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important;backdrop-filter:none!important}
 .search-box h1{display:none}.search-type-switch{justify-content:flex-start;gap:24px}.type-option{font-size:13px;font-weight:500}
 .input-group input{border:1px solid #d8d8dc;border-radius:10px!important;padding:12px 14px!important;font-size:14px;background:#fff}
 input::placeholder{color:#727278}input:focus{border-color:#DF4538!important;box-shadow:0 0 0 3px #DF453818!important}
 .search-btn{border-radius:10px!important;background:#DF4538!important;box-shadow:none!important;padding:0 24px!important}
 .btn-pill{background:#f0f0f2!important;color:#333337!important;border:1px solid #e2e2e5!important;box-shadow:none!important;border-radius:8px!important;font-weight:500!important;font-size:12px!important;padding:9px 12px!important}
 .source-card{background:#f5f5f7!important;box-shadow:none!important;border:1px solid #e1e1e4!important;border-radius:8px!important}.source-checkbox:checked+.source-card{border-color:#DF4538!important;background:#DF453807!important}
 .source-name{color:#3b3b40!important;font-size:12px!important}.source-desc{color:#717177!important}.source-header{margin-top:20px}.source-grid{gap:8px!important}
 .vela-lyrics-empty .aplayer-lrc,.vela-lyrics-empty .karaoke-lyrics{display:none!important}
 .type-option input{accent-color:#DF4538!important}.type-option input:checked+span,.type-option:hover,.source-collapse-btn:hover .source-title{color:#DF4538!important}
 .sakana-container{display:none!important}.right-toolbar{right:12px!important}.rt-btn,.rt-form button{box-shadow:none!important;border:1px solid #e3e3e7;background:#fff!important;color:#63636a!important}
 .song-card{box-shadow:none!important;border-radius:10px!important;border:1px solid #e6e6e9!important}.modal-content{box-shadow:0 12px 40px #0002!important}
 ::selection{background:#DF453822;color:#252527}:focus-visible{outline:2px solid #DF4538;outline-offset:3px}button{cursor:pointer}body::-webkit-scrollbar{width:8px}body::-webkit-scrollbar-thumb{background:#c8c8cf;border-radius:8px}
 `;
 document.head.appendChild(style);
 document.querySelectorAll('[title]').forEach(el=>{if(!el.getAttribute('aria-label'))el.setAttribute('aria-label',el.title)});
 document.querySelector('[onclick="openSystemConfig()"]')?.setAttribute('role','button');
})();
"""#

    fileprivate static let bridgeScript = #"""
(function () {
  const send = () => {
    const session = navigator.mediaSession;
    const metadata = session && session.metadata;
    const audio = typeof ap !== 'undefined' && ap ? ap.audio : document.querySelector('audio');
    const validLyric = text => text && !/^(not available|lrc file request fails.*|暂无歌词)$/i.test(text.trim());
    const lyric = document.querySelector('.aplayer-lrc-current')?.textContent || '';
    const lines = Array.from(document.querySelectorAll('.aplayer-lrc p')).map(el=>el.textContent).filter(validLyric);
    document.body?.classList.toggle('vela-lyrics-empty', lines.length === 0);
    const artwork = metadata && metadata.artwork && metadata.artwork.length ? metadata.artwork[metadata.artwork.length - 1].src : '';
    if (!metadata && !audio) return;
    window.webkit.messageHandlers.musicNowPlaying.postMessage({
      title: metadata && metadata.title || '',
      artist: metadata && metadata.artist || '',
      album: metadata && metadata.album || '',
      artwork,
      playing: session && session.playbackState || (audio && !audio.paused ? 'playing' : 'paused'),
      duration: audio && Number.isFinite(audio.duration) ? audio.duration : 0,
      elapsed: audio && Number.isFinite(audio.currentTime) ? audio.currentTime : 0,
      lyrics: validLyric(lyric) ? lyric : '',
      queueIndex: typeof ap !== 'undefined' && ap ? ap.list.index : 0,
      queue: typeof ap !== 'undefined' && ap ? ap.list.audios.map(t => ({title: t.name, artist: t.artist, cover: t.cover})) : [],
      lyricLines: lines
    });
  };
  const install = () => {
    if (!navigator.mediaSession || window.__diplayBridgeInstalled) return;
    window.__diplayBridgeInstalled = true;
    const proto = Object.getPrototypeOf(navigator.mediaSession);
    const descriptor = Object.getOwnPropertyDescriptor(proto, 'metadata');
    if (descriptor && descriptor.set) {
      Object.defineProperty(proto, 'metadata', { configurable: true, get: descriptor.get, set(value) { descriptor.set.call(this, value); setTimeout(send, 0); } });
    }
    const original = navigator.mediaSession.setActionHandler.bind(navigator.mediaSession);
    const handlers = {};
    navigator.mediaSession.setActionHandler = (action, handler) => { handlers[action] = handler; original(action, handler); };
    window.__diplayPlayerAction = (action, value) => {
      const player = typeof ap !== 'undefined' ? ap : null;
      if (action === 'settings') { window.openSystemConfig?.(); return; }
      if (action === 'showqueue') { player?.list?.show(); return; }
      if (action === 'queueitem' && player) { player.list.switch(value); player.play(); return; }
      const handler = handlers[action];
      if (handler) handler(action === 'seekto' ? {seekTime:value} : {});
      else { const audio = player?.audio || document.querySelector('audio'); if (action === 'play') audio?.play(); if (action === 'pause') audio?.pause(); }
      setTimeout(send, 0);
    };
    for (const event of ['play', 'pause', 'loadedmetadata', 'timeupdate']) document.addEventListener(event, send, true);
    setInterval(send, 1000);
    send();
  };
  install();
  document.addEventListener('DOMContentLoaded', install, { once: true });
  setTimeout(install, 1000);
})();
"""#

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        var model: PlayerHubModel
        weak var webView: WKWebView?
        private var loadedURL = ""
        private var lastSection: PlayerHubModel.Section = .library

        init(model: PlayerHubModel) { self.model = model }

        func reload(_ value: String) {
            if value.isEmpty {
                guard loadedURL != "__waiting__" else { return }
                loadedURL = "__waiting__"
                webView?.loadHTMLString("""
                    <!doctype html><meta charset="utf-8"><style>body{font:14px -apple-system,BlinkMacSystemFont,sans-serif;color:#666;background:#f5f5f7;display:grid;place-items:center;height:90vh;margin:0;text-align:center}main{max-width:430px;padding:32px}h2{font-size:20px;color:#222;font-weight:600}p{line-height:1.7}</style><main><h2>音乐服务正在启动</h2><p>这里会加载音乐搜索、下载和系统设置页面。若长时间停留，请退出并重新打开 Vela。</p></main>
                    """, baseURL: nil)
                return
            }
            guard value != loadedURL, let url = URL(string: value) else { return }
            loadedURL = value
            webView?.load(URLRequest(url: url))
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == "musicNowPlaying", let value = message.body as? [String: Any] else { return }
            Task { @MainActor in model.receiveWebMetadata(value) }
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            Task { @MainActor in
                model.websiteReady = true
                if let index = CommandLine.arguments.firstIndex(of: "--verify-playback"), CommandLine.arguments.count > index + 1,
                   let fixture = try? String(contentsOfFile: CommandLine.arguments[index + 1], encoding: .utf8) {
                    webView.evaluateJavaScript(fixture, completionHandler: nil)
                }

            }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            Task { @MainActor in model.websiteReady = false }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
            if url.isFileURL || url.host == "127.0.0.1" || url.host == "localhost" {
                decisionHandler(.allow)
            } else if navigationAction.navigationType == .linkActivated {
                NSWorkspace.shared.open(url)
                decisionHandler(.cancel)
            } else {
                decisionHandler(.allow)
            }
        }
    }
}

private struct CarPlayVideoPanel: View {
    @ObservedObject var video: CarPlayVideo
    let connected: Bool
    @Binding var pointerInside: Bool
    var body: some View {
        ZStack {
            CarPlayScreen(video: video)
                .opacity(video.hasPresentedFrame ? 1 : 0)
                .allowsHitTesting(video.receiving && !video.reconnecting)
                .accessibilityLabel("iPhone CarPlay 画面")
            if video.hasPresentedFrame && video.reconnecting {
                Label(video.error ?? "正在恢复 CarPlay 画面…", systemImage: "arrow.clockwise")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(.primary)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 9)
                    .background(.regularMaterial, in: Capsule())
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                    .padding(14)
                    .allowsHitTesting(false)
            } else if !video.hasPresentedFrame {
                VStack(spacing: 10) {
                    Image(systemName: "display").font(.system(size: 34, weight: .light)).foregroundStyle(.secondary)
                    Text(video.error ?? (connected ? "正在等待 iPhone 画面…" : "连接 iPhone 后，CarPlay 会显示在这里"))
                        .font(.system(size: 13)).foregroundStyle(.secondary)
                }.padding(24)
            }
        }
        .aspectRatio(video.dimensions.width / video.dimensions.height, contentMode: .fit)
        .frame(maxWidth: .infinity).frame(minHeight: 240)
        .background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 16))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .onHover { pointerInside = $0 }
    }
}
