import Foundation

struct LyricLine: Equatable {
    let time: TimeInterval
    let text: String
    let startsNewLine: Bool

    init(time: TimeInterval, text: String, startsNewLine: Bool = false) {
        self.time = time
        self.text = text
        self.startsNewLine = startsNewLine
    }
}

/// LRC stays on the Mac. Keep repeated timestamps and translations together.
struct Lyrics {
    let rawValue: String
    let lines: [LyricLine]
    let plainText: String
    var isTimed: Bool { !lines.isEmpty }
    var displayLines: [LyricLine] {
        guard let first = lines.first else { return [] }
        var result: [LyricLine] = []
        var start = first.time
        var previous = first.time
        var text = first.text
        for line in lines.dropFirst() {
            let endsPhrase = text.rangeOfCharacter(from: CharacterSet(charactersIn: "。！？!?；;")) != nil
            let hasCJK = text.unicodeScalars.contains { (0x2E80...0x9FFF).contains($0.value) }
            let reachedReadableLength = text.count >= (hasCJK ? 14 : 56)
            if line.startsNewLine || line.time - previous > 1.2 || endsPhrase || reachedReadableLength {
                result.append(LyricLine(time: start, text: text))
                start = line.time
                text = line.text
            } else {
                text += line.text
            }
            previous = line.time
        }
        result.append(LyricLine(time: start, text: text))
        return result
    }

    init(_ raw: String) {
        rawValue = raw
        let timestamp = try! NSRegularExpression(pattern: #"\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]"#)
        let offsetPattern = try! NSRegularExpression(pattern: #"(?i)\[offset:([+-]?\d+)\]"#)
        let offsetMatch = offsetPattern.firstMatch(in: raw, range: NSRange(raw.startIndex..., in: raw))
        let offset = offsetMatch.flatMap { Range($0.range(at: 1), in: raw) }
            .flatMap { Double(raw[$0]) }.map { $0 / 1000 } ?? 0
        var parsed: [LyricLine] = []
        var plain: [String] = []
        for row in raw.components(separatedBy: .newlines) {
            let matches = timestamp.matches(in: row, range: NSRange(row.startIndex..., in: row))
            guard !matches.isEmpty else {
                let text = row.trimmingCharacters(in: .whitespacesAndNewlines)
                if !text.isEmpty && !text.hasPrefix("[") { plain.append(text) }
                continue
            }
            var pendingTimes: [TimeInterval] = []
            var pendingStartsNewLine = false
            for (index, match) in matches.enumerated() {
                let minute = Double((row as NSString).substring(with: match.range(at: 1))) ?? 0
                let second = Double((row as NSString).substring(with: match.range(at: 2))) ?? 0
                let fraction = match.range(at: 3).location == NSNotFound ? "" : (row as NSString).substring(with: match.range(at: 3))
                let decimal = Double("0." + fraction) ?? 0
                pendingTimes.append(max(0, minute * 60 + second + decimal + offset))
                let end = index + 1 < matches.count ? matches[index + 1].range.location : (row as NSString).length
                let contentRange = NSRange(location: NSMaxRange(match.range), length: max(0, end - NSMaxRange(match.range)))
                let rawContent = (row as NSString).substring(with: contentRange)
                let content = rawContent.trimmingCharacters(in: .whitespacesAndNewlines)
                let startsNewLine = pendingStartsNewLine || rawContent.first?.isWhitespace == true
                pendingStartsNewLine = rawContent.last?.isWhitespace == true
                guard !content.isEmpty else {
                    if !rawContent.isEmpty { pendingTimes.removeAll(keepingCapacity: true) }
                    continue
                }
                parsed.append(contentsOf: pendingTimes.map { LyricLine(time: $0, text: content, startsNewLine: startsNewLine) })
                pendingTimes.removeAll(keepingCapacity: true)
            }
        }
        parsed.sort { $0.time < $1.time }
        var grouped: [LyricLine] = []
        for line in parsed {
            if let last = grouped.last, abs(last.time - line.time) < 0.001 {
                if !last.text.components(separatedBy: "\n").contains(line.text) {
                    grouped[grouped.count - 1] = LyricLine(time: last.time, text: last.text + "\n" + line.text, startsNewLine: last.startsNewLine)
                }
            } else { grouped.append(line) }
        }
        lines = grouped
        plainText = plain.joined(separator: "\n")
    }

    func index(at elapsed: TimeInterval) -> Int? {
        guard let first = lines.first, elapsed >= first.time else { return nil }
        var low = 0
        var high = lines.count
        while low < high {
            let mid = (low + high) / 2
            if lines[mid].time <= elapsed { low = mid + 1 } else { high = mid }
        }
        return low - 1
    }

    func displayIndex(at elapsed: TimeInterval) -> Int? {
        let grouped = displayLines
        guard let first = grouped.first, elapsed >= first.time else { return nil }
        var low = 0, high = grouped.count
        while low < high {
            let mid = (low + high) / 2
            if grouped[mid].time <= elapsed { low = mid + 1 } else { high = mid }
        }
        return low - 1
    }
}
