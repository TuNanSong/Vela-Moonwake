import Foundation
import ImageIO
import UniformTypeIdentifiers

/// Matches CarPlay artwork and stable song titles through the bundled catalog helper.
final class MetadataResolver {
    private struct Response: Decodable {
        let coverURL: String?
        let lyrics: String?
    }
    private struct Cached { let cover: Data?; let expiresAt: Date }
    private struct LyricsCacheEntry { let lyrics: String?; let expiresAt: Date }
    private let lock = NSLock()
    private var generation: UInt64 = 0
    private var process: Process?
    private var download: URLSessionDataTask?
    private var cache: [String: Cached] = [:]
    private var cacheOrder: [String] = []
    private var lyricsCache: [String: LyricsCacheEntry] = [:]
    private var lyricsCacheOrder: [String] = []
    private let work = DispatchQueue(label: "com.codex.vela.metadata", qos: .utility)
    private let session: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 8
        configuration.timeoutIntervalForResource = 12
        configuration.urlCache = nil
        return URLSession(configuration: configuration)
    }()

    func cancel() {
        lock.lock()
        generation &+= 1
        let oldProcess = process
        let oldDownload = download
        process = nil
        download = nil
        lock.unlock()
        if oldProcess?.isRunning == true { oldProcess?.terminate() }
        oldDownload?.cancel()
    }

    func resolveArtwork(artist: String, album: String, completion: @escaping (Data?) -> Void) {
        let cleanArtist = artist.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanAlbum = album.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanAlbum.isEmpty, !cleanArtist.isEmpty else {
            DispatchQueue.main.async { completion(nil) }
            return
        }
        cancel()
        let key = [cleanArtist, cleanAlbum].joined(separator: "\u{1f}").lowercased()
        lock.lock()
        let token = generation
        let cached = cache[key]
        lock.unlock()
        if let cached, cached.expiresAt > Date() {
            completion(cached.cover)
            return
        }
        work.asyncAfter(deadline: .now() + 0.2) { [weak self] in
            guard let self, self.isCurrent(token) else { return }
            self.lookup(artist: cleanArtist, album: cleanAlbum, key: key, token: token, completion: completion)
        }
    }

    func resolveLyrics(title: String, artist: String, album: String, durationMillis: Int64,
                       completion: @escaping (String?) -> Void) {
        let cleanTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanArtist = artist.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanAlbum = album.trimmingCharacters(in: .whitespacesAndNewlines)
        guard cleanTitle.count >= 2, !cleanArtist.isEmpty else {
            DispatchQueue.main.async { completion(nil) }
            return
        }
        cancel()
        let key = [cleanTitle, cleanArtist, cleanAlbum, String(max(0, durationMillis) / 1000)]
            .joined(separator: "\u{1f}").lowercased()
        lock.lock()
        let token = generation
        let cached = lyricsCache[key]
        lock.unlock()
        if let cached, cached.expiresAt > Date() {
            DispatchQueue.main.async { [weak self] in
                guard let self, self.isCurrent(token) else { return }
                completion(cached.lyrics)
            }
            return
        }
        work.asyncAfter(deadline: .now() + 0.2) { [weak self] in
            guard let self, self.isCurrent(token) else { return }
            self.lookupLyrics(title: cleanTitle, artist: cleanArtist, album: cleanAlbum,
                              durationMillis: durationMillis, key: key, token: token,
                              allowSwappedRetry: true, completion: completion)
        }
    }

    private func isCurrent(_ token: UInt64) -> Bool {
        lock.lock(); defer { lock.unlock() }
        return generation == token
    }

    private func publish(_ cover: Data?, key: String, token: UInt64, completion: @escaping (Data?) -> Void) {
        DispatchQueue.main.async { [weak self] in
            guard let self, self.isCurrent(token) else { return }
            self.remember(cover, key: key, token: token)
            completion(cover)
        }
    }

    private func remember(_ cover: Data?, key: String, token: UInt64) {
        lock.lock(); defer { lock.unlock() }
        guard generation == token else { return }
        cache[key] = Cached(cover: cover, expiresAt: Date().addingTimeInterval(cover == nil ? 300 : 3600))
        cacheOrder.removeAll { $0 == key }
        cacheOrder.append(key)
        while cacheOrder.count > 32 { cache.removeValue(forKey: cacheOrder.removeFirst()) }
    }

    private func publishLyrics(_ lyrics: String?, key: String, token: UInt64,
                               completion: @escaping (String?) -> Void) {
        DispatchQueue.main.async { [weak self] in
            guard let self, self.isCurrent(token) else { return }
            self.lock.lock()
            guard self.generation == token else { self.lock.unlock(); return }
            self.lyricsCache[key] = LyricsCacheEntry(lyrics: lyrics, expiresAt: Date().addingTimeInterval(lyrics == nil ? 300 : 3600))
            self.lyricsCacheOrder.removeAll { $0 == key }
            self.lyricsCacheOrder.append(key)
            while self.lyricsCacheOrder.count > 32 {
                self.lyricsCache.removeValue(forKey: self.lyricsCacheOrder.removeFirst())
            }
            self.lock.unlock()
            completion(lyrics)
        }
    }

    private func lookupLyrics(title: String, artist: String, album: String, durationMillis: Int64,
                              key: String, token: UInt64, allowSwappedRetry: Bool,
                              completion: @escaping (String?) -> Void) {
        let helper = Bundle.main.bundleURL.appendingPathComponent("Contents/MacOS/diplay-metadata")
        guard FileManager.default.isExecutableFile(atPath: helper.path) else {
            publishLyrics(nil, key: key, token: token, completion: completion)
            return
        }
        let child = Process()
        let input = Pipe()
        let output = Pipe()
        child.executableURL = helper
        child.standardInput = input
        child.standardOutput = output
        child.standardError = FileHandle.nullDevice
        do {
            let request: [String: Any] = ["title": title, "artist": artist, "album": album,
                                          "durationMillis": max(0, durationMillis)]
            let data = try JSONSerialization.data(withJSONObject: request)
            lock.lock()
            guard generation == token else { lock.unlock(); return }
            do { try child.run() } catch { lock.unlock(); throw error }
            process = child
            lock.unlock()
            defer {
                lock.lock()
                if process === child { process = nil }
                lock.unlock()
            }
            try input.fileHandleForWriting.write(contentsOf: data)
            try input.fileHandleForWriting.close()
            let timeout = DispatchWorkItem { if child.isRunning { child.terminate() } }
            DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 15, execute: timeout)
            defer { timeout.cancel() }
            let reply = try output.fileHandleForReading.readToEnd() ?? Data()
            child.waitUntilExit()
            guard isCurrent(token), child.terminationStatus == 0, reply.count <= 1024 * 1024,
                  let result = try? JSONDecoder().decode(Response.self, from: reply) else {
                publishLyrics(nil, key: key, token: token, completion: completion)
                return
            }
            if let lyrics = result.lyrics, !lyrics.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                publishLyrics(lyrics, key: key, token: token, completion: completion)
                return
            }
            let sameValue = artist.trimmingCharacters(in: .whitespacesAndNewlines)
                .caseInsensitiveCompare(album.trimmingCharacters(in: .whitespacesAndNewlines)) == .orderedSame
            guard allowSwappedRetry, !album.isEmpty, !sameValue else {
                publishLyrics(nil, key: key, token: token, completion: completion)
                return
            }
            lookupLyrics(title: title, artist: album, album: artist, durationMillis: durationMillis,
                         key: key, token: token, allowSwappedRetry: false, completion: completion)
        } catch {
            if child.isRunning { child.terminate() }
            publishLyrics(nil, key: key, token: token, completion: completion)
        }
    }

    private func lookup(artist: String, album: String, key: String, token: UInt64,
                        allowSwappedRetry: Bool = true, completion: @escaping (Data?) -> Void) {
        let helper = Bundle.main.bundleURL.appendingPathComponent("Contents/MacOS/diplay-metadata")
        guard FileManager.default.isExecutableFile(atPath: helper.path) else {
            publish(nil, key: key, token: token, completion: completion)
            return
        }
        let child = Process()
        let input = Pipe()
        let output = Pipe()
        child.executableURL = helper
        child.standardInput = input
        child.standardOutput = output
        child.standardError = FileHandle.nullDevice
        do {
            let request: [String: Any] = ["title": "", "artist": artist, "album": album]
            let data = try JSONSerialization.data(withJSONObject: request)
            lock.lock()
            guard generation == token else { lock.unlock(); return }
            do { try child.run() } catch { lock.unlock(); throw error }
            process = child
            lock.unlock()
            defer {
                lock.lock()
                if process === child { process = nil }
                lock.unlock()
            }
            try input.fileHandleForWriting.write(contentsOf: data)
            try input.fileHandleForWriting.close()
            let timeout = DispatchWorkItem { if child.isRunning { child.terminate() } }
            DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 15, execute: timeout)
            defer { timeout.cancel() }
            let reply = try output.fileHandleForReading.readToEnd() ?? Data()
            child.waitUntilExit()
            guard isCurrent(token), child.terminationStatus == 0, reply.count <= 1024 * 1024,
                  let result = try? JSONDecoder().decode(Response.self, from: reply) else {
                publish(nil, key: key, token: token, completion: completion)
                return
            }
            guard let urlString = result.coverURL,
                  let originalURL = URL(string: urlString), originalURL.scheme == "https" else {
                let sameValue = artist.trimmingCharacters(in: .whitespacesAndNewlines)
                    .caseInsensitiveCompare(album.trimmingCharacters(in: .whitespacesAndNewlines)) == .orderedSame
                guard allowSwappedRetry, !sameValue else {
                    publish(nil, key: key, token: token, completion: completion)
                    return
                }
                // Some CarPlay metadata providers swap the artist and album fields.
                // Retry once with the visible pair reversed, then cache the same result.
                lookup(artist: album, album: artist, key: key, token: token,
                       allowSwappedRetry: false, completion: completion)
                return
            }
            var components = URLComponents(url: originalURL, resolvingAgainstBaseURL: false)
            if originalURL.host?.hasSuffix(".music.126.net") == true {
                var query = components?.queryItems ?? []
                query.removeAll { $0.name == "param" }
                query.append(URLQueryItem(name: "param", value: "512y512"))
                components?.queryItems = query
            }
            let url = components?.url ?? originalURL
            let task = session.dataTask(with: url) { [weak self] bytes, response, _ in
                guard let self, self.isCurrent(token), let bytes, bytes.count <= 4 * 1024 * 1024,
                      (response as? HTTPURLResponse)?.statusCode == 200,
                      let cover = Self.thumbnail(bytes) else {
                    self?.publish(nil, key: key, token: token, completion: completion)
                    return
                }
                self.publish(cover, key: key, token: token, completion: completion)
            }
            lock.lock()
            if generation == token { download = task; task.resume() }
            else { task.cancel() }
            lock.unlock()
        } catch {
            if child.isRunning { child.terminate() }
            publish(nil, key: key, token: token, completion: completion)
        }
    }

    private static func thumbnail(_ data: Data) -> Data? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: 512,
                kCGImageSourceShouldCacheImmediately: true
              ] as CFDictionary) else { return nil }
        let result = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(result, UTType.png.identifier as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(destination, image, nil)
        guard CGImageDestinationFinalize(destination) else { return nil }
        return result as Data
    }
}
