import Darwin
import Foundation

@MainActor final class CarPlayControlClient {
    private var timer: Timer?
    private var polling = false
    private var touchBatchTimer: Timer?
    private var pendingTouches: [[String: Any]] = []
    private var audioPending: [String:Any]?
    private var audioSending = false
    private let touchQueue = DispatchQueue(label:"Vela.CarPlay.touch", qos:.userInteractive)
    var onStatus: (([String: Any]?) -> Void)?
    func start() {
        poll()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.poll() }
        }
    }
    func stop() { timer?.invalidate(); timer = nil }
    /// App termination is synchronous; ensure a Vela-owned engine receives its stop command.
    /// A standalone MacPlay session is preserved.
    func stopEmbeddedReceiver() {
        guard let request=try? JSONSerialization.data(withJSONObject:["action":"status"]),
              let response=Self.exchange(request,timeoutSeconds:0.5),
              let status=(try? JSONSerialization.jsonObject(with:response)) as? [String:Any],
              status["serviceMode"] as? Bool == true, status["embeddedVideo"] as? Bool == true, status["running"] as? Bool == true,
              let stop=try? JSONSerialization.data(withJSONObject:["action":"stop"]) else { return }
        _ = Self.exchange(stop,timeoutSeconds:2.5)
    }
    private func poll() {
        guard !polling else { return }
        polling = true
        request("status") { [weak self] value in
            self?.polling = false
            self?.onStatus?(value?["serviceMode"] as? Bool == true ? value : nil)
        }
    }
    func request(_ action: String, value: Double? = nil, properties: [String: Any] = [:], completion: @escaping ([String: Any]?) -> Void) {
        var message: [String: Any] = properties
        message["action"] = action
        if let value { message["value"] = value }
        guard let data = try? JSONSerialization.data(withJSONObject: message) else { completion(nil); return }
        let timeout = ["connect", "start", "stop"].contains(action) ? 8 : 2
        Task {
            let result = await Task.detached(priority: .utility) { Self.exchange(data, timeoutSeconds: Double(timeout)) }.value
            let object = result.flatMap { (try? JSONSerialization.jsonObject(with: $0)) as? [String: Any] }
            completion(object)
        }
    }
    /// Coalesce slider movement while preserving the final selected value.
    func audio(volume:Double,callVolume:Double,enabled:Bool,completion:@escaping (String?) -> Void) {
        audioPending=["volume":volume,"callVolume":callVolume,"enabled":enabled]
        sendAudio(completion:completion)
    }
    private func sendAudio(completion:@escaping (String?) -> Void) {
        guard !audioSending,let properties=audioPending else {return}
        audioPending=nil;audioSending=true
        request("audio",properties:properties) { [weak self] response in
            guard let self else {return}
            self.audioSending=false
            completion(response?["ok"] as? Bool == true ? nil : response?["error"] as? String ?? "音量未更新，请重试")
            self.sendAudio(completion:completion)
        }
    }
    func touch(x:Double, y:Double, down:Bool) {
        pendingTouches.append(["x":x,"y":y,"down":down])
        if !down || pendingTouches.count >= 32 { flushTouchBatch(); return }
        guard touchBatchTimer == nil else { return }
        // Trackpad deltas can arrive faster than the control socket needs to
        // open. Send a short FIFO batch at display cadence without discarding
        // any points in the gesture.
        touchBatchTimer = Timer.scheduledTimer(withTimeInterval:1.0/60.0,repeats:false) { [weak self] _ in
            MainActor.assumeIsolated { self?.flushTouchBatch() }
        }
    }
    private func flushTouchBatch() {
        touchBatchTimer?.invalidate(); touchBatchTimer=nil
        guard !pendingTouches.isEmpty else { return }
        let events=pendingTouches; pendingTouches=[]
        guard let data=try? JSONSerialization.data(withJSONObject:["action":"touchBatch","events":events]) else { return }
        touchQueue.async {
            _ = Self.exchange(data,timeoutSeconds:0.25)
        }
    }
    nonisolated private static func exchange(_ request: Data, timeoutSeconds: Double) -> Data? {
        let path = "/tmp/vela-receiver-\(getuid()).sock"
        let fd = socket(AF_UNIX, SOCK_STREAM, 0)
        guard fd >= 0 else { return nil }
        defer { close(fd) }
        _ = fcntl(fd, F_SETFD, FD_CLOEXEC)
        var address = sockaddr_un()
        address.sun_family = sa_family_t(AF_UNIX)
        address.sun_len = UInt8(MemoryLayout<sockaddr_un>.size)
        withUnsafeMutableBytes(of: &address.sun_path) { $0.copyBytes(from: Array(path.utf8) + [0]) }
        guard withUnsafePointer(to: &address, { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { connect(fd, $0, socklen_t(MemoryLayout<sockaddr_un>.size)) } }) == 0 else { return nil }
        var uid: uid_t = 0, gid: gid_t = 0
        guard getpeereid(fd, &uid, &gid) == 0, uid == getuid() else { return nil }
        var timeout = timeval(tv_sec: Int(timeoutSeconds), tv_usec: Int32((timeoutSeconds - floor(timeoutSeconds)) * 1_000_000)), noSignal: Int32 = 1
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, socklen_t(MemoryLayout<timeval>.size))
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, socklen_t(MemoryLayout<timeval>.size))
        setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &noSignal, socklen_t(MemoryLayout<Int32>.size))
        var bytes = request; bytes.append(0x0a)
        let count = bytes.withUnsafeBytes { write(fd, $0.baseAddress, bytes.count) }
        guard count == bytes.count else { return nil }
        var pending = Data(), buffer = [UInt8](repeating: 0, count: 4096)
        while pending.count < 32_768 {
            let count = read(fd, &buffer, buffer.count)
            if count < 0 && errno == EINTR { continue }
            guard count > 0 else { return nil }
            pending.append(contentsOf: buffer.prefix(count))
            if let end = pending.firstIndex(of: 0x0a) { return Data(pending[..<end]) }
        }
        return nil
    }
}
