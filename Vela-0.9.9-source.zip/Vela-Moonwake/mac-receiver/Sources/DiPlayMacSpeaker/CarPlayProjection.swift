// SPDX-License-Identifier: GPL-3.0-or-later
import AppKit
import AVFoundation
import SwiftUI

/// Owns the auxiliary projection window; the embedded and projection views each
/// render the same incoming samples through their own display layer.
@MainActor final class CarPlayProjection: NSObject, ObservableObject, NSWindowDelegate {
    @Published var fullscreen = false
    private var window: NSWindow?
    private var video: CarPlayVideo?
    private var pendingPresentation: (UInt32, Bool)?
    func show(displayID: UInt32, fullscreen requested: Bool, video source: CarPlayVideo) {
        let screen = displayID == 0
            ? (NSScreen.main ?? NSScreen.screens.first)
            : (NSScreen.screens.first { Self.displayID($0) == displayID } ?? NSScreen.main ?? NSScreen.screens.first)
        let targetDisplayID = Self.displayID(screen)
        if let window, window.styleMask.contains(.fullScreen) {
            if Self.displayID(window.screen) != targetDisplayID {
                pendingPresentation = (targetDisplayID, requested); window.toggleFullScreen(nil); return
            }
            window.makeKeyAndOrderFront(nil)
            if !requested { window.toggleFullScreen(nil) }
            return
        }
        if window == nil {
            video = source
            let panel = NSWindow(contentRect: NSRect(x:0,y:0,width:1000,height:650),styleMask:[.titled,.closable,.miniaturizable,.resizable],backing:.buffered,defer:false)
            panel.title = "Vela · CarPlay 投屏"; panel.isReleasedWhenClosed = false
            panel.titlebarAppearsTransparent = true
            panel.collectionBehavior = [.fullScreenPrimary]; panel.minSize = NSSize(width:480,height:320)
            panel.delegate = self
            panel.contentView = NSHostingView(rootView:ProjectionSurface(video:source,display:source.projectionDisplay,projection:self))
            window = panel
        }
        guard let window else { return }
        if let screen {
            let area = screen.visibleFrame
            let width = min(1100, area.width * 0.9), height = min(760, area.height * 0.9)
            window.setFrame(NSRect(x:area.midX-width/2,y:area.midY-height/2,width:width,height:height),display:true)
        }
        window.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps:true)
        if requested { window.toggleFullScreen(nil) }
    }
    static func displayID(_ screen:NSScreen?) -> UInt32 {
        (screen?.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber)?.uint32Value ?? 0
    }
    func toggleFullscreen() { window?.toggleFullScreen(nil) }
    func close() { window?.close() }
    func windowDidEnterFullScreen(_ notification:Notification) { fullscreen = true }
    func windowDidExitFullScreen(_ notification:Notification) {
        fullscreen = false
        if let pending = pendingPresentation, let video { pendingPresentation=nil;show(displayID:pending.0,fullscreen:pending.1,video:video) }
    }
    func windowWillClose(_ notification:Notification) {
        pendingPresentation=nil
        video?.restoreEmbeddedDisplay()
        video=nil; window?.contentView=nil; window=nil; fullscreen=false
    }
}
private struct ProjectionSurface: View {
    @ObservedObject var video:CarPlayVideo
    let display: AVSampleBufferDisplayLayer
    @ObservedObject var projection:CarPlayProjection
    var body:some View {
        VStack(spacing:0) {
            if !projection.fullscreen {
                HStack {
                    Label("iPhone CarPlay",systemImage:"iphone").font(.callout.weight(.medium))
                    Spacer()
                    Button("全屏") { projection.toggleFullscreen() }
                    Button("返回应用") { projection.close() }
                }.padding(.horizontal,16).padding(.vertical,10).background(.bar)
            }
            ZStack {
                Color.black
                CarPlayScreen(video:video,display:display,projection:true)
                if video.hasProjectionPresentedFrame && video.projectionReconnecting {
                    Label(video.error ?? "正在恢复 CarPlay 画面…", systemImage:"arrow.clockwise")
                        .font(.callout.weight(.medium))
                        .foregroundStyle(.white)
                        .padding(.horizontal,14).padding(.vertical,10)
                        .background(.ultraThinMaterial,in:Capsule())
                        .frame(maxWidth:.infinity,maxHeight:.infinity,alignment:.topLeading)
                        .padding(18)
                        .allowsHitTesting(false)
                } else if !video.hasProjectionPresentedFrame {
                    Text(video.error ?? "正在等待 iPhone 画面…").foregroundStyle(.white.opacity(0.8)).allowsHitTesting(false)
                }
            }.frame(maxWidth:.infinity,maxHeight:.infinity)
        }.frame(minWidth:480,minHeight:280).background(.black).onExitCommand { projection.toggleFullscreen() }
    }
}
