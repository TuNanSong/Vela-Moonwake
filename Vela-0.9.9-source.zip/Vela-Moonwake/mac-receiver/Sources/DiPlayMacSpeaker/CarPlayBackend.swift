// SPDX-License-Identifier: GPL-3.0-or-later
import Foundation
import Darwin

@MainActor final class CarPlayBackend {
    private var process: Process?
    var onError: ((String) -> Void)?
    var isRunning: Bool { process?.isRunning == true }
    static var executable: URL {
        Bundle.main.bundleURL.appendingPathComponent("Contents/Helpers/VelaCarPlayService.app/Contents/MacOS/VelaCarPlayService")
    }
    static var isBundled: Bool { FileManager.default.isExecutableFile(atPath: executable.path) }
    func start() {
        guard !isRunning else { return }
        guard Self.isBundled else { onError?("此安装包缺少 iPhone 接收后端，请重新安装完整 Vela。"); return }
        let child=Process();child.executableURL=Self.executable
        var env=ProcessInfo.processInfo.environment;env["VELA_OWNER_PID"]=String(getpid());env["VELA_PRODUCT_NAME"]="Vela"
        child.environment=env;child.standardInput=FileHandle.nullDevice;child.standardOutput=FileHandle.nullDevice;child.standardError=FileHandle.nullDevice
        child.terminationHandler={ [weak self] task in Task { @MainActor in
            guard self?.process === task else { return };self?.process=nil
            if task.terminationStatus != 0 { self?.onError?("iPhone 接收端已退出，请重新启动接收端。") }
        } }
        do { try child.run();process=child } catch { onError?("iPhone 接收端无法启动：\(error.localizedDescription)") }
    }
    func stop() {
        guard let child=process else { return };process=nil
        guard child.isRunning else { return }
        child.terminate()
        let deadline=Date().addingTimeInterval(3)
        while child.isRunning,Date()<deadline { Thread.sleep(forTimeInterval:0.01) }
        if child.isRunning { kill(child.processIdentifier,SIGKILL) }
        child.waitUntilExit()
    }
}

struct CarPlayConfiguration: Codable {
    struct Choice: Codable, Identifiable { var id: String; var name: String }
    struct Display: Codable, Identifiable { var id: UInt32; var name: String }
    var resolution: String
    var fps: Int
    var displayID: UInt32
    var width: Int
    var height: Int
    var autoStartUSB: Bool?
    var audioEnabled: Bool
    var volume: Double
    var callVolume: Double
    var outputDevice: String
    var inputDevice: String
    var ssid: String
    var channel: Int
    var wifiInterface: String
    var passwordSaved: Bool
    var credentialsReady: Bool
    var displays: [Display]
    var outputs: [Choice]
    var inputs: [Choice]
    func request(password:String,clearPassword:Bool) -> [String:Any] {
        var data: [String:Any] = ["resolution":resolution,"fps":fps,"displayID":displayID,"width":width,"height":height,
        "autoStartUSB":autoStartUSB ?? false,"audioEnabled":audioEnabled,"volume":volume,"callVolume":callVolume,"outputDevice":outputDevice,"inputDevice":inputDevice,
        "ssid":ssid,"channel":channel,"wifiInterface":wifiInterface,"clearPassword":clearPassword]
        if !password.isEmpty { data["password"]=password }
        return data
    }
}
