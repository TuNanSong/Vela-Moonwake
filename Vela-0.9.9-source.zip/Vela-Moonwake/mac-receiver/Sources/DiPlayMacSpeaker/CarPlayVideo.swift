// SPDX-License-Identifier: GPL-3.0-or-later
import AppKit
import AVFoundation
import CoreMedia
import Darwin
import SwiftUI

/// Codec records and decrypted length-prefixed video, carried over a same-user socket.
/// Authentication and pairing data never enter this interface.
@MainActor final class CarPlayVideo: ObservableObject {
    let display = AVSampleBufferDisplayLayer()
    let projectionDisplay = AVSampleBufferDisplayLayer()
    @Published var receiving = false
    @Published private(set) var hasPresentedFrame = false
    @Published private(set) var reconnecting = false
    @Published private(set) var hasProjectionPresentedFrame = false
    @Published private(set) var projectionReconnecting = false
    @Published var error: String?
    @Published var dimensions = CGSize(width: 16, height: 9)
    var onTouch: ((Double, Double, Bool) -> Void)?
    private var reader: DispatchSourceRead?
    private var retry: Timer?
    private var pending = Data()
    private var format: CMVideoFormatDescription?
    private weak var embeddedScreenView: CarPlayScreenView?
    private(set) var projectionActive = false
    private var hevc = false
    private var nalLength = 4
    private var waitingForKeyframe = true
    private var displaysAwaitingKeyframe: Set<ObjectIdentifier> = []
    private var stopped = false

    init() {
        for display in [display, projectionDisplay] {
            display.videoGravity = .resizeAspect
            display.backgroundColor = NSColor.black.cgColor
            displaysAwaitingKeyframe.insert(ObjectIdentifier(display))
        }
    }
    func registerScreenView(_ view: CarPlayScreenView, projection: Bool) {
        if projection {
            if !projectionActive {
                projectionActive = true
                projectionDisplay.sampleBufferRenderer.flush(removingDisplayedImage: true, completionHandler: nil)
                displaysAwaitingKeyframe.insert(ObjectIdentifier(projectionDisplay))
                hasProjectionPresentedFrame = false
                projectionReconnecting = true
            }
        } else {
            embeddedScreenView = view
            view.attachVideoDisplay()
        }
    }
    func restoreEmbeddedDisplay() {
        projectionActive = false
        projectionDisplay.sampleBufferRenderer.flush(removingDisplayedImage: true, completionHandler: nil)
        displaysAwaitingKeyframe.insert(ObjectIdentifier(projectionDisplay))
        hasProjectionPresentedFrame = false
        projectionReconnecting = false
        embeddedScreenView?.attachVideoDisplay()
    }
    private var activeDisplays: [AVSampleBufferDisplayLayer] { projectionActive ? [display, projectionDisplay] : [display] }
    func clearPresentedFrame() {
        [display, projectionDisplay].forEach { $0.sampleBufferRenderer.flush(removingDisplayedImage: true, completionHandler: nil) }
        pending.removeAll(keepingCapacity: true)
        format = nil
        waitingForKeyframe = true
        displaysAwaitingKeyframe = [ObjectIdentifier(display), ObjectIdentifier(projectionDisplay)]
        receiving = false
        hasPresentedFrame = false
        reconnecting = false
        hasProjectionPresentedFrame = false
        projectionReconnecting = false
        error = nil
    }
    func start() {
        guard !stopped, reader == nil else { return }
        let fd = socket(AF_UNIX, SOCK_STREAM, 0)
        guard fd >= 0 else { scheduleRetry(); return }
        _ = fcntl(fd, F_SETFD, FD_CLOEXEC)
        var address = sockaddr_un(); address.sun_family = sa_family_t(AF_UNIX)
        address.sun_len = UInt8(MemoryLayout<sockaddr_un>.size)
        let path = "/tmp/vela-video-\(getuid()).sock"
        withUnsafeMutableBytes(of: &address.sun_path) { $0.copyBytes(from: Array(path.utf8) + [0]) }
        let connected = withUnsafePointer(to: &address) { $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { connect(fd, $0, socklen_t(MemoryLayout<sockaddr_un>.size)) == 0 } }
        var uid: uid_t = 0, gid: gid_t = 0
        guard connected, getpeereid(fd, &uid, &gid) == 0, uid == getuid(), fcntl(fd, F_SETFL, O_NONBLOCK) == 0 else {
            close(fd); scheduleRetry(); return
        }
        pending.removeAll(keepingCapacity: true); format = nil; waitingForKeyframe = true
        reconnecting = hasPresentedFrame
        projectionReconnecting = hasProjectionPresentedFrame
        let source = DispatchSource.makeReadSource(fileDescriptor: fd, queue: .main)
        source.setEventHandler { [weak self] in MainActor.assumeIsolated { self?.readPackets(fd) } }
        source.setCancelHandler { close(fd) }
        reader = source; source.resume()
    }
    private func readPackets(_ fd: Int32) {
        var bytes = [UInt8](repeating: 0, count: 65536)
        for _ in 0..<16 {
            let count = read(fd, &bytes, bytes.count)
            if count < 0 && errno == EINTR { continue }
            if count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK) { return }
            guard count > 0 else { disconnected(); return }
            pending.append(contentsOf: bytes.prefix(count))
            while pending.count >= 4 {
                let length = pending.prefix(4).reduce(0) { $0 << 8 | Int($1) }
                guard length >= 1, length <= 8 * 1024 * 1024 + 1 else { error = "视频数据格式不正确"; disconnected(); return }
                guard pending.count >= length + 4 else { break }
                let kind = pending[pending.startIndex + 4]
                let payload = Data(pending[(pending.startIndex + 5)..<(pending.startIndex + 4 + length)])
                pending.removeFirst(length + 4)
                consume(kind: kind, payload: payload)
            }
        }
    }
    /// Also used by the hardware-independent codec check; production input uses readPackets.
    func consume(kind: UInt8, payload: Data) {
        do {
            switch kind {
            case 1, 2:
                // Keep the last visible frame while the next codec/keyframe is prepared.
                // A late projection window can receive a format refresh mid-session.
                activeDisplays.forEach { $0.sampleBufferRenderer.flush(removingDisplayedImage: !hasPresentedFrame, completionHandler: nil) }
                activeDisplays.forEach { displaysAwaitingKeyframe.insert(ObjectIdentifier($0)) }
                receiving = hasPresentedFrame; reconnecting = hasPresentedFrame; waitingForKeyframe = true
                projectionReconnecting = hasProjectionPresentedFrame
                hevc = kind == 2
                format = nil
                format = try makeFormat(payload, hevc: hevc)
                if let format {
                    let size = CMVideoFormatDescriptionGetDimensions(format)
                    dimensions = CGSize(width: Int(size.width), height: Int(size.height))
                }
                error = nil
            case 3: try enqueue(payload)
            default: throw VideoError.invalidRecord
            }
        } catch {
            self.error = "无法显示 CarPlay 画面：\(error.localizedDescription)"
            receiving = hasPresentedFrame; reconnecting = hasPresentedFrame; waitingForKeyframe = true
            activeDisplays.forEach { $0.sampleBufferRenderer.flush(removingDisplayedImage: !hasPresentedFrame, completionHandler: nil) }
            activeDisplays.forEach { displaysAwaitingKeyframe.insert(ObjectIdentifier($0)) }
            projectionReconnecting = hasProjectionPresentedFrame
        }
    }
    private func makeFormat(_ data: Data, hevc: Bool) throws -> CMVideoFormatDescription {
        let bytes = Array(data)
        var offset = hevc ? 23 : 6
        guard bytes.count > offset, bytes[0] == 1 else { throw VideoError.invalidRecord }
        nalLength = Int(bytes[hevc ? 21 : 4] & 3) + 1
        guard [1, 2, 4].contains(nalLength) else { throw VideoError.invalidRecord }
        func takeNAL() throws -> [UInt8] {
            guard offset + 2 <= bytes.count else { throw VideoError.invalidRecord }
            let length = Int(bytes[offset]) << 8 | Int(bytes[offset + 1]); offset += 2
            guard length > 0, offset + length <= bytes.count else { throw VideoError.invalidRecord }
            defer { offset += length }; return Array(bytes[offset..<(offset + length)])
        }
        var sets: [[UInt8]] = []
        if hevc {
            for _ in 0..<Int(bytes[22]) {
                guard offset + 3 <= bytes.count else { throw VideoError.invalidRecord }
                let type = bytes[offset] & 0x3f
                let count = Int(bytes[offset + 1]) << 8 | Int(bytes[offset + 2]); offset += 3
                for _ in 0..<count { let nal = try takeNAL(); if [32,33,34].contains(type) { sets.append(nal) } }
            }
        } else {
            for _ in 0..<Int(bytes[5] & 31) { sets.append(try takeNAL()) }
            guard offset < bytes.count else { throw VideoError.invalidRecord }
            let count = Int(bytes[offset]); offset += 1
            for _ in 0..<count { sets.append(try takeNAL()) }
        }
        guard sets.count >= 2 else { throw VideoError.invalidRecord }
        let storage = sets.map { set -> UnsafeMutablePointer<UInt8> in
            let ptr = UnsafeMutablePointer<UInt8>.allocate(capacity: set.count)
            ptr.initialize(from: set, count: set.count); return ptr
        }
        defer { storage.forEach { $0.deallocate() } }
        let pointers = storage.map { UnsafePointer($0) }; let sizes = sets.map(\.count)
        var result: CMFormatDescription?
        let code = pointers.withUnsafeBufferPointer { pp in sizes.withUnsafeBufferPointer { ss in
            if hevc { return CMVideoFormatDescriptionCreateFromHEVCParameterSets(allocator: kCFAllocatorDefault, parameterSetCount: sets.count, parameterSetPointers: pp.baseAddress!, parameterSetSizes: ss.baseAddress!, nalUnitHeaderLength: Int32(nalLength), extensions: nil, formatDescriptionOut: &result) }
            return CMVideoFormatDescriptionCreateFromH264ParameterSets(allocator: kCFAllocatorDefault, parameterSetCount: sets.count, parameterSetPointers: pp.baseAddress!, parameterSetSizes: ss.baseAddress!, nalUnitHeaderLength: Int32(nalLength), formatDescriptionOut: &result)
        } }
        guard code == noErr, let result else { throw VideoError.status(code) }; return result
    }
    private func enqueue(_ data: Data) throws {
        guard let format else { return }
        guard !data.isEmpty else { throw VideoError.invalidRecord }
        let bytes = Array(data); var offset = 0; var keyframe = false
        while offset < bytes.count {
            guard offset + nalLength <= bytes.count else { throw VideoError.invalidRecord }
            var count = 0
            for byte in bytes[offset..<(offset + nalLength)] { count = count << 8 | Int(byte) }; offset += nalLength
            guard count > 0, count <= bytes.count - offset else { throw VideoError.invalidRecord }
            let type = hevc ? (bytes[offset] >> 1) & 0x3f : bytes[offset] & 31
            if hevc ? (16...21).contains(type) : type == 5 { keyframe = true }
            offset += count
        }
        guard !waitingForKeyframe || keyframe else { return }
        if waitingForKeyframe && keyframe { waitingForKeyframe = false }
        var block: CMBlockBuffer?
        let blockCode = CMBlockBufferCreateWithMemoryBlock(allocator:kCFAllocatorDefault,memoryBlock:nil,blockLength:data.count,blockAllocator:kCFAllocatorDefault,customBlockSource:nil,offsetToData:0,dataLength:data.count,flags:0,blockBufferOut:&block)
        guard blockCode == noErr, let block else { throw VideoError.status(blockCode) }
        let replace = data.withUnsafeBytes { CMBlockBufferReplaceDataBytes(with:$0.baseAddress!,blockBuffer:block,offsetIntoDestination:0,dataLength:data.count) }
        guard replace == noErr else { throw VideoError.status(replace) }
        var sample: CMSampleBuffer?
        var timing = CMSampleTimingInfo(duration:.invalid,presentationTimeStamp:CMTime(seconds:ProcessInfo.processInfo.systemUptime,preferredTimescale:1_000_000),decodeTimeStamp:.invalid)
        var size = data.count
        let code = CMSampleBufferCreateReady(allocator:kCFAllocatorDefault,dataBuffer:block,formatDescription:format,sampleCount:1,sampleTimingEntryCount:1,sampleTimingArray:&timing,sampleSizeEntryCount:1,sampleSizeArray:&size,sampleBufferOut:&sample)
        guard code == noErr, let sample else { throw VideoError.status(code) }
        if let attachments = CMSampleBufferGetSampleAttachmentsArray(sample,createIfNecessary:true) as? [NSMutableDictionary], let first = attachments.first { first[kCMSampleAttachmentKey_DisplayImmediately] = true }
        var enqueuedMainDisplay = false
        for target in activeDisplays {
            let id = ObjectIdentifier(target)
            if displaysAwaitingKeyframe.contains(id) && !keyframe { continue }
            let renderer = target.sampleBufferRenderer
            if renderer.status == .failed {
                renderer.flush(removingDisplayedImage: false, completionHandler: nil)
                displaysAwaitingKeyframe.insert(id)
                if id == ObjectIdentifier(display) { receiving = false; reconnecting = hasPresentedFrame }
                if id == ObjectIdentifier(projectionDisplay) { projectionReconnecting = hasProjectionPresentedFrame }
                continue
            }
            // One busy window must not stall the other. Resync only that renderer
            // at the next keyframe while the other keeps receiving every frame.
            guard renderer.isReadyForMoreMediaData else {
                renderer.flush(removingDisplayedImage: false, completionHandler: nil)
                displaysAwaitingKeyframe.insert(id)
                if id == ObjectIdentifier(display) { receiving = false; reconnecting = hasPresentedFrame }
                if id == ObjectIdentifier(projectionDisplay) { projectionReconnecting = hasProjectionPresentedFrame }
                continue
            }
            renderer.enqueue(sample)
            displaysAwaitingKeyframe.remove(id)
            if id == ObjectIdentifier(display) { enqueuedMainDisplay = true }
            if id == ObjectIdentifier(projectionDisplay) {
                hasProjectionPresentedFrame = true
                projectionReconnecting = false
            }
        }
        if enqueuedMainDisplay {
            receiving = true; hasPresentedFrame = true; reconnecting = false; error = nil
        }
    }
    private func disconnected() {
        reader?.cancel(); reader = nil; pending.removeAll(); format = nil
        // A video socket can be dropped for a brief slow-client burst. Discard
        // queued samples but keep the last presented image until a new keyframe
        // arrives; a full flush here made both windows flash black on reconnect.
        activeDisplays.forEach { $0.sampleBufferRenderer.flush(removingDisplayedImage: false, completionHandler: nil) }
        activeDisplays.forEach { displaysAwaitingKeyframe.insert(ObjectIdentifier($0)) }
        receiving = false; reconnecting = hasPresentedFrame; waitingForKeyframe = true; scheduleRetry()
        projectionReconnecting = hasProjectionPresentedFrame
    }
    private func scheduleRetry() {
        guard !stopped, retry == nil else { return }
        retry = Timer.scheduledTimer(withTimeInterval:1,repeats:false) { [weak self] _ in MainActor.assumeIsolated { self?.retry = nil; self?.start() } }
    }
    func stop() { stopped = true; retry?.invalidate(); retry = nil; reader?.cancel(); reader = nil; clearPresentedFrame() }
    enum VideoError: LocalizedError {
        case invalidRecord, status(OSStatus), decoder(String)
        var errorDescription: String? { switch self { case .invalidRecord:return "视频格式不正确"; case .status(let code):return "解码错误 \(code)"; case .decoder(let text):return text } }
    }
}

struct CarPlayScreen: NSViewRepresentable {
    @ObservedObject var video: CarPlayVideo
    var display: AVSampleBufferDisplayLayer? = nil
    var projection = false
    func makeNSView(context: Context) -> CarPlayScreenView { CarPlayScreenView(video:video, display:display ?? video.display, projection:projection) }
    func updateNSView(_ view: CarPlayScreenView, context: Context) { view.video = video; view.needsLayout = true }
}
@MainActor final class CarPlayScreenView: NSView {
    var video: CarPlayVideo
    private let videoDisplay: AVSampleBufferDisplayLayer
    private var touching = false
    private var lastMove = 0.0
    private var lastContact = CGPoint.zero
    private let isProjection: Bool
    init(video: CarPlayVideo, display: AVSampleBufferDisplayLayer, projection: Bool = false) {
        self.video = video; self.videoDisplay = display; self.isProjection = projection
        super.init(frame:.zero); wantsLayer = true
        video.registerScreenView(self, projection:projection)
    }
    required init?(coder:NSCoder) { fatalError("init(coder:) has not been implemented") }
    override var acceptsFirstResponder: Bool { true }
    override func layout() {
        super.layout()
        attachVideoDisplay()
    }
    func attachVideoDisplay() {
        guard let layer else { return }
        if videoDisplay.superlayer !== layer { layer.addSublayer(videoDisplay) }
        videoDisplay.frame = bounds
    }
    static func normalizedPoint(_ point:CGPoint, bounds:CGRect, dimensions:CGSize, clamp:Bool) -> CGPoint? {
        guard dimensions.width > 0, dimensions.height > 0, bounds.width > 0, bounds.height > 0 else { return nil }
        let scale = min(bounds.width/dimensions.width,bounds.height/dimensions.height)
        let rect = CGRect(x:bounds.minX+(bounds.width-dimensions.width*scale)/2,y:bounds.minY+(bounds.height-dimensions.height*scale)/2,width:dimensions.width*scale,height:dimensions.height*scale)
        guard clamp || rect.contains(point) else { return nil }
        return CGPoint(x:min(1,max(0,(point.x-rect.minX)/rect.width)),y:min(1,max(0,1-(point.y-rect.minY)/rect.height)))
    }
    private static func aspectRect(bounds: CGRect, dimensions: CGSize) -> CGRect? {
        guard dimensions.width > 0, dimensions.height > 0, bounds.width > 0, bounds.height > 0 else { return nil }
        let scale = min(bounds.width / dimensions.width, bounds.height / dimensions.height)
        return CGRect(x: bounds.midX - dimensions.width * scale / 2,
                      y: bounds.midY - dimensions.height * scale / 2,
                      width: dimensions.width * scale,
                      height: dimensions.height * scale)
    }
    @discardableResult private func send(_ event:NSEvent, down:Bool, clamp:Bool) -> Bool {
        guard video.receiving, !video.reconnecting, let p=Self.normalizedPoint(convert(event.locationInWindow,from:nil),bounds:bounds,dimensions:video.dimensions,clamp:clamp) else { return false }
        lastContact=p; video.onTouch?(p.x,p.y,down); return true
    }
    private var scrollPoint = CGPoint.zero
    private var scrollActive = false
    private var scrollEndTimer: Timer?
    private func finishScroll() {
        scrollEndTimer?.invalidate(); scrollEndTimer = nil
        guard scrollActive else { return }
        video.onTouch?(scrollPoint.x, scrollPoint.y, false)
        scrollActive = false
    }
    override func mouseDown(with event:NSEvent) { finishScroll(); touching = send(event,down:true,clamp:false) }
    override func mouseDragged(with event:NSEvent) { guard touching, event.timestamp-lastMove >= 1/60 else { return }; lastMove = event.timestamp; send(event,down:true,clamp:true) }
    override func mouseUp(with event:NSEvent) { guard touching else { return }; touching = false; send(event,down:false,clamp:true) }
    override func scrollWheel(with event: NSEvent) {
        guard !touching else { return }
        // Match MacPlay: CarPlay owns the fling, so ignore macOS momentum and
        // feed each real scroll delta into one continuous CarPlay touch.
        if !event.momentumPhase.isEmpty { finishScroll(); return }
        if event.phase.contains(.ended) || event.phase.contains(.cancelled) { finishScroll(); return }
        guard video.receiving, !video.reconnecting, let rect = Self.aspectRect(bounds: bounds, dimensions: video.dimensions) else {
            finishScroll(); super.scrollWheel(with: event); return
        }
        var dx = event.scrollingDeltaX
        var dy = event.scrollingDeltaY
        if !event.hasPreciseScrollingDeltas { dx *= 12; dy *= 12 }
        guard dx != 0 || dy != 0 else { return }
        if !scrollActive {
            let point = convert(event.locationInWindow, from: nil)
            guard let normalized = Self.normalizedPoint(point, bounds: bounds, dimensions: video.dimensions, clamp: false) else { return }
            scrollPoint = normalized
            scrollActive = true
            video.onTouch?(scrollPoint.x, scrollPoint.y, true)
        }
        scrollPoint.x = min(1, max(0, scrollPoint.x + dx / rect.width))
        scrollPoint.y = min(1, max(0, scrollPoint.y + dy / rect.height))
        video.onTouch?(scrollPoint.x, scrollPoint.y, true)
        scrollEndTimer?.invalidate()
        scrollEndTimer = Timer.scheduledTimer(withTimeInterval: 0.15, repeats: false) { [weak self] _ in
            MainActor.assumeIsolated { self?.finishScroll() }
        }
    }
    override func viewWillMove(toWindow newWindow:NSWindow?) {
        if newWindow == nil { finishScroll() }
        if newWindow == nil, touching { video.onTouch?(lastContact.x,lastContact.y,false); touching=false }
        super.viewWillMove(toWindow:newWindow)
    }
}
