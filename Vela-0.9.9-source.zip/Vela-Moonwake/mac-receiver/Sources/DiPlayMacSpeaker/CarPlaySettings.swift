import SwiftUI
import AppKit

struct CarPlaySettings: View {
    @Environment(\.dismiss) private var dismiss
    @State private var draft: CarPlayConfiguration
    @State private var password = ""
    @State private var clearPassword = false
    @State private var saving = false
    @State private var error: String?
    let onSave: (CarPlayConfiguration,String,Bool,@escaping (String?) -> Void) -> Void
    init(configuration:CarPlayConfiguration,onSave:@escaping (CarPlayConfiguration,String,Bool,@escaping (String?) -> Void) -> Void) {
        _draft=State(initialValue:configuration);self.onSave=onSave
    }
    var body: some View {
        VStack(spacing:0) {
            HStack { Text("iPhone 连接设置").font(.title2.weight(.semibold));Spacer();Button("取消") { dismiss() }.keyboardShortcut(.cancelAction) }.padding(22)
            Form {
                Section("显示") {
                    Picker("显示器",selection:$draft.displayID) { ForEach(draft.displays) { Text($0.name).tag($0.id) } }
                    Picker("分辨率",selection:$draft.resolution) {
                        Text("屏幕原生像素").tag("native")
                        ForEach(["1280x720","1920x1080","2560x1440"],id:\.self) { Text($0.replacingOccurrences(of:"x",with:" × ")).tag($0) }
                        Text("自定义").tag("custom")
                    }
                    if draft.resolution == "custom" {
                        TextField("宽度",value:$draft.width,format:.number)
                        TextField("高度",value:$draft.height,format:.number)
                    }
                    Picker("最高帧率",selection:$draft.fps) { ForEach([30,60,90,120],id:\.self) { Text("\($0) fps").tag($0) } }
                    Text("高帧率需要 iPhone 支持；协商失败时会自动降低帧率。").font(.caption).foregroundStyle(.secondary)
                }
                Section("接入") {
                    Toggle("USB 接入时自动连接",isOn:Binding(get:{draft.autoStartUSB ?? false},set:{draft.autoStartUSB=$0}))
                    Text("Vela 运行期间，插入并解锁所选 iPhone 后自动开始内嵌投屏。").font(.caption).foregroundStyle(.secondary)
                }
                Section("音频") {
                    Toggle("播放 iPhone 音频",isOn:$draft.audioEnabled)
                    Picker("输出设备",selection:$draft.outputDevice) { Text("系统默认").tag("");ForEach(draft.outputs) { Text($0.name).tag($0.id) } }
                    Picker("麦克风",selection:$draft.inputDevice) { Text("系统默认").tag("");ForEach(draft.inputs) { Text($0.name).tag($0.id) } }
                    LabeledContent("音乐音量") { Slider(value:$draft.volume,in:0...1).frame(width:200) }
                    LabeledContent("通话音量") { Slider(value:$draft.callVolume,in:0...1).frame(width:200) }
                }
                Section("无线连接") {
                    TextField("Wi-Fi 名称",text:$draft.ssid)
                    SecureField(draft.passwordSaved ? "新密码（留空保留已保存密码）" : "Wi-Fi 密码",text:$password)
                    if draft.passwordSaved { Toggle("清除已保存的密码",isOn:$clearPassword) }
                    TextField("网络接口",text:$draft.wifiInterface)
                    Stepper("信道 \(draft.channel)",value:$draft.channel,in:1...196)
                    Text("Mac 和 iPhone 需要加入同一 Wi-Fi，并完成蓝牙配对。USB 连接无需填写这些信息。").font(.caption).foregroundStyle(.secondary)
                }
                Section("认证配置") {
                    Label(draft.credentialsReady ? "本机认证配置已就绪" : "本机尚未配置接收认证",systemImage:draft.credentialsReady ? "checkmark.circle" : "folder")
                    Button("打开本机认证目录") {
                        NSWorkspace.shared.open(FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support/MacPlay/authentication"))
                    }
                }
            }.formStyle(.grouped)
            HStack {
                if let error { Text(error).font(.caption).foregroundStyle(.red) }
                Spacer()
                Button(saving ? "正在保存…" : "保存") {
                    saving=true;error=nil
                    onSave(draft,password,clearPassword) { failure in
                        saving=false
                        if let failure { error=failure } else { password="";dismiss() }
                    }
                }.buttonStyle(.borderedProminent).disabled(saving).keyboardShortcut(.defaultAction)
            }.padding(20)
        }.frame(width:620,height:700)
    }
}
