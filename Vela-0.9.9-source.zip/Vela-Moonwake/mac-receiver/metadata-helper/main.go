package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"net/url"
	"os"
	"sort"
	"strings"
	"sync"
	"time"
	"unicode"

	"github.com/guohuiyuan/music-lib/apple"
	"github.com/guohuiyuan/music-lib/joox"
	"github.com/guohuiyuan/music-lib/kugou"
	"github.com/guohuiyuan/music-lib/migu"
	"github.com/guohuiyuan/music-lib/model"
	"github.com/guohuiyuan/music-lib/netease"
	"github.com/guohuiyuan/music-lib/qianqian"
	"github.com/guohuiyuan/music-lib/qq"
	"github.com/guohuiyuan/music-lib/soda"
)

type request struct {
	Title    string `json:"title"`
	Artist   string `json:"artist"`
	Album    string `json:"album"`
	Duration int64  `json:"durationMillis"`
}

type response struct {
	CoverURL string `json:"coverURL,omitempty"`
	Lyrics   string `json:"lyrics,omitempty"`
}

type source struct {
	name   string
	search func(string) ([]model.Song, error)
	lyrics func(*model.Song) (string, error)
}

type match struct {
	source source
	song   model.Song
	score  float64
}

func main() {
	var input request
	if err := json.NewDecoder(bufio.NewReader(os.Stdin)).Decode(&input); err != nil {
		write(response{})
		return
	}
	write(resolve(input))
}

func resolve(q request) response {
	// Album naming varies between services; use it to rank, not to restrict search.
	query := strings.TrimSpace(strings.Join([]string{q.Title, q.Artist}, " "))
	if query == "" {
		return response{}
	}
	sources := []source{
		{name: "apple", search: apple.New("").Search, lyrics: apple.New("").GetLyrics},
		{name: "netease", search: netease.New("").Search, lyrics: netease.New("").GetLyrics},
		{name: "qq", search: qq.New("").Search, lyrics: qq.New("").GetLyrics},
		{name: "kugou", search: kugou.New("").Search, lyrics: kugou.New("").GetLyrics},
		{name: "migu", search: migu.New("").Search, lyrics: migu.New("").GetLyrics},
		{name: "qianqian", search: qianqian.New("").Search, lyrics: qianqian.New("").GetLyrics},
		{name: "joox", search: joox.New("").Search, lyrics: joox.New("").GetLyrics},
		{name: "soda", search: soda.New("").Search, lyrics: soda.New("").GetLyrics},
	}

	var mu sync.Mutex
	var matches []match
	var albumCover string
	var albumScore float64
	var wg sync.WaitGroup
	// Album artwork can still be available when a service hides full-song search results.
	if strings.TrimSpace(q.Album) != "" {
		for _, search := range []func(string) ([]model.Playlist, error){netease.New("").SearchAlbum, qq.New("").SearchAlbum, kugou.New("").SearchAlbum} {
			search := search
			wg.Add(1)
			go func() {
				defer wg.Done()
				albums, err := search(strings.TrimSpace(q.Album + " " + q.Artist))
				if err != nil {
					return
				}
				for _, album := range albums {
					nameScore, artistScore := textScore(q.Album, album.Name), textScore(q.Artist, album.Creator)
					cover := secureCoverURL(album.Cover)
					if nameScore < 0.7 || artistScore < 0.7 || cover == "" {
						continue
					}
					mu.Lock()
					if score := nameScore + artistScore; score > albumScore {
						albumScore, albumCover = score, cover
					}
					mu.Unlock()
				}
			}()
		}
	}
	if query != "" {
		for _, provider := range sources {
			provider := provider
			wg.Add(1)
			go func() {
				defer wg.Done()
				songs, err := provider.search(query)
				if err != nil {
					return
				}
				for _, song := range songs {
					score := matchScore(q, song)
					if score < 1.38 || textScore(q.Title, song.Name) < 0.62 {
						continue
					}
					mu.Lock()
					matches = append(matches, match{source: provider, song: song, score: score})
					mu.Unlock()
				}
			}()
		}
	}
	done := make(chan struct{})
	go func() { wg.Wait(); close(done) }()
	select {
	case <-done:
	case <-time.After(8 * time.Second):
	}
	mu.Lock()
	candidates := append([]match(nil), matches...)
	coverFromAlbum := albumCover
	mu.Unlock()
	sort.SliceStable(candidates, func(i, j int) bool { return candidates[i].score > candidates[j].score })
	if len(candidates) == 0 {
		return response{CoverURL: coverFromAlbum}
	}

	result := response{CoverURL: coverFromAlbum}
	// Select artwork independently; successful lyrics must not end the cover search.
	for _, candidate := range candidates {
		if cover := secureCoverURL(candidate.song.Cover); result.CoverURL == "" && cover != "" {
			result.CoverURL = cover
			break
		}
	}
	// Several catalogs return artwork but no lyrics. Ask the best matching lyric
	// candidates together so one slow provider cannot block all fallback sources.
	type lyricMatch struct {
		candidate match
		lyric     string
	}
	var lyricCandidates []match
	for _, candidate := range candidates {
		if candidate.score >= 1.38 && len(lyricCandidates) < 4 {
			lyricCandidates = append(lyricCandidates, candidate)
		}
	}
	lyricResults := make(chan lyricMatch, len(lyricCandidates))
	for _, candidate := range lyricCandidates {
		candidate := candidate
		go func() {
			lyric, _ := candidate.source.lyrics(&candidate.song)
			lyricResults <- lyricMatch{candidate: candidate, lyric: lyric}
		}()
	}
	deadline := time.NewTimer(5 * time.Second)
	defer deadline.Stop()
	var lyricMatches []lyricMatch
	for len(lyricMatches) < len(lyricCandidates) {
		select {
		case found := <-lyricResults:
			if strings.TrimSpace(found.lyric) != "" {
				lyricMatches = append(lyricMatches, found)
			}
		case <-deadline.C:
			goto lyricsDone
		}
	}
lyricsDone:
	sort.SliceStable(lyricMatches, func(i, j int) bool {
		return lyricMatches[i].candidate.score > lyricMatches[j].candidate.score
	})
	if len(lyricMatches) > 0 {
		result.Lyrics = lyricMatches[0].lyric
	}
	return result
}

func matchScore(q request, song model.Song) float64 {
	for _, version := range []string{"铃声", "伴奏", "翻唱", "live", "remix", "加速"} {
		if strings.Contains(strings.ToLower(song.Name), version) != strings.Contains(strings.ToLower(q.Title), version) {
			return 0
		}
	}
	title := textScore(q.Title, song.Name)
	artist := textScore(q.Artist, song.Artist)
	album := textScore(q.Album, song.Album)
	score := title*1.1 + artist*0.7 + album*0.2
	if q.Duration > 0 && song.Duration > 0 {
		delta := abs(int(q.Duration/1000) - song.Duration)
		switch {
		case delta <= 2:
			score += 0.28
		case delta <= 6:
			score += 0.16
		case delta <= 12:
			score += 0.06
		case delta > 30:
			score -= 0.9
		}
	}
	return score
}

func textScore(want, got string) float64 {
	a, b := normalize(want), normalize(got)
	if a == "" || b == "" {
		return 0
	}
	if a == b {
		return 1
	}
	if strings.Contains(a, b) || strings.Contains(b, a) {
		shorter, longer := len([]rune(a)), len([]rune(b))
		if shorter > longer {
			shorter, longer = longer, shorter
		}
		if longer == 0 {
			return 0
		}
		return 0.68 + 0.30*float64(shorter)/float64(longer)
	}
	as, bs := runeSet(a), runeSet(b)
	common := 0
	for r := range as {
		if _, ok := bs[r]; ok {
			common++
		}
	}
	union := len(as) + len(bs) - common
	if union == 0 {
		return 0
	}
	return float64(common) / float64(union)
}

func secureCoverURL(raw string) string {
	if strings.HasPrefix(raw, "//") {
		raw = "https:" + raw
	}
	u, err := url.Parse(raw)
	if err != nil || u.Hostname() == "" || (u.Scheme != "http" && u.Scheme != "https") {
		return ""
	}
	u.Scheme = "https"
	return u.String()
}

func normalize(value string) string {
	var out strings.Builder
	for _, r := range strings.ToLower(strings.TrimSpace(value)) {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			out.WriteRune(r)
		}
	}
	return out.String()
}

func runeSet(value string) map[rune]struct{} {
	result := make(map[rune]struct{})
	for _, r := range value {
		result[r] = struct{}{}
	}
	return result
}

func abs(value int) int {
	if value < 0 {
		return -value
	}
	return value
}

func write(result response) {
	if err := json.NewEncoder(os.Stdout).Encode(result); err != nil {
		fmt.Fprintln(os.Stderr, err)
	}
}
