module diplay-metadata

go 1.23.0

require github.com/guohuiyuan/music-lib v1.1.1-0.20260916154859-28e1080ba416
