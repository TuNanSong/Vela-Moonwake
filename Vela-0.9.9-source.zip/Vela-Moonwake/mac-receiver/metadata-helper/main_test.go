package main

import (
    "testing"
    "github.com/guohuiyuan/music-lib/model"
)

func TestRejectRingtoneAndWrongDuration(t *testing.T) {
    q := request{Title: "7-11 的爱恋", Artist: "梦飞船", Duration: 280000}
    if matchScore(q, model.Song{Name: "7-11 的爱恋 (45秒铃声版)", Artist: "梦飞船", Duration: 45}) >= 1.38 { t.Fatal("ringtone matched full song") }
    if matchScore(q, model.Song{Name: q.Title, Artist: q.Artist, Duration: 45}) >= 1.38 { t.Fatal("short version matched full song") }
}

func TestTextScoreBoundedAndSymmetric(t *testing.T) {
	for _, pair := range [][2]string{{"a long song name", "song"}, {"7-11 的爱恋", "7-11 的爱恋 (7-11 Love)"}} {
		a, b := textScore(pair[0], pair[1]), textScore(pair[1], pair[0])
		if a > 1 || a != b {
			t.Fatalf("invalid score %v %v", a, b)
		}
	}
}

func TestSecureCoverURL(t *testing.T) {
	for raw, want := range map[string]string{
		"http://p1.music.126.net/a.jpg": "https://p1.music.126.net/a.jpg",
		"//y.gtimg.cn/cover.jpg": "https://y.gtimg.cn/cover.jpg",
		"file:///tmp/cover.jpg": "",
		"": "",
	} {
		if got := secureCoverURL(raw); got != want { t.Fatalf("%q -> %q, want %q", raw, got, want) }
	}
}
