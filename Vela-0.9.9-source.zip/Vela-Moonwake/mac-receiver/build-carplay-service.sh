#!/bin/bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SERVICE="$1/Contents/Helpers/VelaCarPlayService.app"
: "${MACPLAY_SOURCE_ROOT:?Supply the patched MacPlay source checkout}"
MACPLAY_RUNTIME_APP="${MACPLAY_RUNTIME_APP:-/Applications/MacPlay.app}"
ENGINE_BUILD="${MACPLAY_ENGINE_BUILD:-$MACPLAY_SOURCE_ROOT/build/engine}"
if [[ ! -f "$ENGINE_BUILD/velaVideo.js" || ! -f "$MACPLAY_SOURCE_ROOT/native/App/VelaService.swift" ]]; then
    echo "Apply the Vela integration patch and compile the MacPlay engine first." >&2; exit 1
fi
mkdir -p "$SERVICE/Contents/MacOS" "$SERVICE/Contents/Resources"
swiftc -DVELA_SERVICE -parse-as-library -O -target arm64-apple-macosx14.0 \
    -framework SwiftUI -framework AppKit -framework CoreWLAN -framework CoreLocation \
    -framework IOKit -framework IOBluetooth -framework CoreAudio -framework MediaPlayer \
    "$MACPLAY_SOURCE_ROOT/native/App/MacPlay.swift" \
    "$MACPLAY_SOURCE_ROOT/native/App/ApplicationLifecycle.swift" \
    "$MACPLAY_SOURCE_ROOT/native/App/About.swift" "$MACPLAY_SOURCE_ROOT/native/App/Localization.swift" \
    "$MACPLAY_SOURCE_ROOT/native/App/NowPlayingState.swift" "$MACPLAY_SOURCE_ROOT/native/App/NowPlayingFeed.swift" \
    "$MACPLAY_SOURCE_ROOT/native/App/VelaControlServer.swift" "$MACPLAY_SOURCE_ROOT/native/App/VelaService.swift" \
    -o "$SERVICE/Contents/MacOS/VelaCarPlayService"
cp "$SCRIPT_DIR/Resources/CarPlayService.plist" "$SERVICE/Contents/Info.plist"
# Deliberately copy only receiver code/runtime and upstream license notices.
# Never copy the source app wholesale: it can include authentication resources.
for directory in runtime engine driver gstreamer icons GStreamer-LICENSES ThirdParty-LICENSES; do
    [[ -e "$MACPLAY_RUNTIME_APP/Contents/Resources/$directory" ]] || { echo "Missing runtime component: $directory" >&2; exit 1; }
    if [[ -n "$(find "$MACPLAY_RUNTIME_APP/Contents/Resources/$directory" \( -iname identity.pk8 -o -iname certificate.p7b -o -iname settings.json -o -iname authentication \) -print -quit)" ]]; then
        echo "Runtime component includes private configuration or authentication; refusing to copy it." >&2; exit 1
    fi
    ditto --norsrc "$MACPLAY_RUNTIME_APP/Contents/Resources/$directory" "$SERVICE/Contents/Resources/$directory"
done
for name in LICENSE NOTICE; do cp "$MACPLAY_RUNTIME_APP/Contents/Resources/$name" "$SERVICE/Contents/Resources/$name"; done
if [[ -n "${VELA_AUTH_SOURCE_DIR:-}" ]]; then
    for name in identity.pk8 certificate.p7b; do
        [[ -f "$VELA_AUTH_SOURCE_DIR/$name" ]] || { echo "Missing local CarPlay authentication file: $name" >&2; exit 1; }
    done
    AUTH_DEST="$SERVICE/Contents/Resources/authentication"
    mkdir -p "$AUTH_DEST"
    cp "$VELA_AUTH_SOURCE_DIR/identity.pk8" "$VELA_AUTH_SOURCE_DIR/certificate.p7b" "$AUTH_DEST/"
    chmod 600 "$AUTH_DEST/identity.pk8" "$AUTH_DEST/certificate.p7b"
fi
ditto --norsrc "$ENGINE_BUILD" "$SERVICE/Contents/Resources/engine"
# Reject user settings everywhere, and credentials outside the explicitly selected local input.
if [[ -n "$(find "$SERVICE" -iname settings.json -print -quit)" ]]; then
    echo "Receiver package unexpectedly contains user settings." >&2; exit 1
fi
if [[ -n "${VELA_AUTH_SOURCE_DIR:-}" ]]; then
    if [[ -n "$(find "$SERVICE" -path "$SERVICE/Contents/Resources/authentication" -prune -o \( -iname identity.pk8 -o -iname certificate.p7b -o -iname authentication \) -print -quit)" ]]; then
        echo "Receiver package contains authentication outside the selected local input." >&2; exit 1
    fi
else
  if [[ -n "$(find "$SERVICE" \( -iname identity.pk8 -o -iname certificate.p7b -o -iname authentication \) -print -quit)" ]]; then
    echo "Receiver package unexpectedly contains authentication or user settings." >&2; exit 1
  fi
fi

# Compile the patched wireless bridge rather than reusing the upstream binary.
clang -fobjc-arc -arch arm64 -mmacosx-version-min=14.0 -framework Foundation -framework AppKit -framework IOBluetooth -framework CoreBluetooth \
    -sectcreate __TEXT __info_plist "$MACPLAY_SOURCE_ROOT/native/macplay-bluetooth/Info.plist" \
    "$MACPLAY_SOURCE_ROOT/native/macplay-bluetooth/main.m" -o "$SERVICE/Contents/Resources/driver/macplay-bluetooth"
cp "$SCRIPT_DIR/Resources/Vela-Coral.icns" "$SERVICE/Contents/Resources/Vela-Coral.icns"
for size in 256 512; do cp "$SCRIPT_DIR/Resources/CarPlay-$size.png" "$SERVICE/Contents/Resources/icons/macplay-$size.png"; done
python3 - "$SERVICE/Contents/Resources/runtime/MacPlayReceiver.app" "$SCRIPT_DIR/Resources/Vela-Coral.icns" <<'PYTHON'
import plistlib,sys,shutil
from pathlib import Path
app=Path(sys.argv[1]);info=app/'Contents/Info.plist'
data=plistlib.loads(info.read_bytes());data['CFBundleName']='Vela CarPlay';data['CFBundleDisplayName']='Vela CarPlay';data['CFBundleIconFile']='Vela-Coral';data['NSMicrophoneUsageDescription']='Vela 使用麦克风进行 Siri 语音控制和通话。'
info.write_bytes(plistlib.dumps(data,sort_keys=False));shutil.copyfile(sys.argv[2],app/'Contents/Resources/Vela-Coral.icns')
PYTHON
