// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "DiPlayMacSpeaker",
    platforms: [.macOS("26.0")],
    products: [
        .executable(name: "DiPlayMacSpeaker", targets: ["DiPlayMacSpeaker"]),
    ],
    dependencies: [],
    targets: [
        .executableTarget(
            name: "DiPlayMacSpeaker",
            dependencies: [],
        ),
        .testTarget(name: "DiPlayMacSpeakerTests", dependencies: ["DiPlayMacSpeaker"]),
    ],
)
