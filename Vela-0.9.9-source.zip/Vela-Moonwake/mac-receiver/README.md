# Vela macOS 应用

此目录包含 Vela 的原生 Mac 应用源码、CarPlay 服务打包脚本和封面/歌词匹配助手。仓库根目录的 README 说明完整依赖和构建流程。

## 构建产物

```sh
./mac-receiver/build-mac-app.sh "$PWD/dist"
```

构建前设置 `MACPLAY_SOURCE_ROOT`、`MACPLAY_RUNTIME_APP`、`MACPLAY_ENGINE_BUILD` 和 `MUSIC_DL_ROOT`。接收服务构建会拒绝从 MacPlay 运行时复制认证密钥或用户设置；请使用上游项目中合法授权的本机配置。

构建脚本默认目标为 Apple 芯片的 arm64。生成的 `.app` 和 `.zip` 写入 `dist/`，不应提交到源码仓库。应用当前最低系统版本为 macOS 26。

## 子目录

- `Sources/DiPlayMacSpeaker/`：SwiftUI 应用、CarPlay 投屏、播放状态和本地媒体控制。
- `metadata-helper/`：用 Go Music DL 的 `music-lib` 搜索匹配的封面和歌词。
- `Resources/`：应用和 CarPlay 图标、服务 `Info.plist`、MacPlay 许可文本。
- `build-carplay-service.sh`：构建应用内无窗口 CarPlay 接收服务。
- `build-mac-app.sh`：构建、装配、签名并压缩整个 Vela 应用。
